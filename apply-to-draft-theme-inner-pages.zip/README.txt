FURNISQUARE — INNER PAGES (Bulk Order + About Us + FAQ + Contact + Cancel Order + Franchise + Our Story + Navigation + Help & Contact + Media & News)
Scope: draft theme 130907209857 ("Furnisquare Theme", Draft). DO NOT apply to the live theme.
(custom.css and every pre-existing theme file are intentionally NOT included — do not touch them.)

NEW IN v1.19 (Help & Contact + Media & News pages)
  New: sections/inner-map.liquid ("Inner Map / Visit") — Find us band: heading, address,
       quick-link blocks (icon/label/link/new tab) + Google Maps iframe (embed src as a setting).
  New: sections/inner-reviews.liquid ("Inner Reviews") — reviews band: heading + lede + optional
       button; one block per review (quote + attribution). Cream band default ON.
  New: sections/inner-press.liquid ("Inner Press Band") — press/media enquiry band: heading +
       lede + quick-link blocks. Cream band default ON.
  New: sections/inner-media.liquid ("Inner Media") — the ANI lead story (date, heading, text,
       image URL, 2 buttons) + searchable "Coverage" grid. Each publication is an editable block
       (name / domain / article URL / thumbnail URL); search + "Show more" (12 at a time) are
       vanilla JS scoped to the section. 31 publications pre-filled with their live URLs and
       this store's CDN thumbnails (no Files upload needed).
  New: templates/page.help-contact.json — plain hero (facts Trade name / Customer care) ->
       4 contact cards (Call 24/7 / WhatsApp / Email / Visit us) -> FAQ (cream band, 10 Q&A
       from the mockup, "Read all FAQs" link) -> Find us in Ratangarh (map + quick links) ->
       reviews band (3 real reviews verbatim) -> trust strip.
  New: templates/page.media-news.json — plain hero -> Inner Media (lead story + 31 outlets) ->
       press & media enquiries band -> trust strip.
  inner-faq.liquid gained: "Cream band background" checkbox (default OFF — live FAQ page unchanged),
       "Aside lede" (optional textarea, blank by default), "Below-help link label/URL"
       (optional — renders a "Read all FAQs"-style link under the help box).
  assets/acustom.css: .hm__* / .mm__* styles ported from the mockup css/help-media.css
       (grids collapse at 1100/900/640px).
  IMAGES: none to upload — outlet thumbnails and the lead image hot-link this store's CDN.
  Live template names confirmed by client: page.help-contact.json / page.media-news.json.
  Re-upload: sections inner-map, inner-reviews, inner-press, inner-media (NEW), inner-faq.liquid
       (replace), assets/acustom.css (replace), templates/page.help-contact.json (NEW),
       templates/page.media-news.json (NEW).

NEW IN v1.18 (Navigation page — footer menus + no Shop all)
  page.navigation.json: the two Link columns now point at the menus the draft theme footer actually
    assigns — Information column => menu handle "information", Useful links => "useful-links"
    (see sections/footer-group.json in the theme, which pins these). The earlier handles
    footer-information / footer-useful-links do not exist in this store, so both columns rendered
    empty. In the customizer you can re-pick menus any time; no code change needed.
  inner-sitemap.liquid: the "Shop all …" link under each category column is REMOVED
    (setting and render code removed).
  Section presets now default to the same handles (information / useful-links).
  acustom.css: unused .smap__all rule removed.
  IMAGES: none.
  Re-upload: sections/inner-sitemap.liquid, templates/page.navigation.json, assets/acustom.css.

NEW IN v1.17 (Navigation page — schema fix)
  inner-sitemap.liquid: removed the block-level "default" from both link_list settings.
  Shopify rejects link_list defaults inside blocks ("Invalid block 'menu_flat': setting with
  id='menu' default is invalid") — only section-level link_list may carry a default. Menu handles
  are pinned by the template (page.navigation.json) and the presets, and can be re-picked in the
  customizer, so nothing else changes. Re-upload sections/inner-sitemap.liquid only.

NEW IN v1.16 (Navigation page)
  New: sections/inner-sitemap.liquid ("Inner Sitemap") — menu-driven sitemap; columns render
       straight from the menus assigned in the customizer, so the page always mirrors the live
       header/footer (no manual link lists to maintain).
       • "Menu columns (3-level)" block: one column per top-level menu item (linked heading) ->
         linked group headings -> their links. Groups assigned with no links render as a
         clickable heading (e.g. Swing Jhula / Mirrors / Dining Chairs). Optional "Shop all"
         link per column (default ON). Default menu: main-menu.
       • "Link column" block: a flat menu as a simple column (default: footer-information).
       Wired in the template: main-menu columns + "Help & information" (footer-information)
       + "Orders & policies" (footer-useful-links) = the mockup's 8 columns, with ONLY the
       categories that are actually assigned in the live menus.
  New: templates/page.navigation.json — plain hero (eyebrow "Navigation",
       Find your way <em>around</em>, lede "Every Furnisquare category and page in one place.",
       facts Trade name / Phone / Email) + Inner Sitemap.
       Live template name confirmed by client: page.navigation.json.
  assets/acustom.css: .smap / .smap__col / .smap__all styles (4 -> 3 -> 2 columns).
  IMAGES: none — this page has no images.
  NOTE: sitemap content = whatever is in the menus (Online Store > Menus). Links appear/disappear
    automatically as menus are edited. STUDY has no dropdown (direct /collections/study link), so
    it renders as a direct-link column. Footer menus (Information / Useful links) feed the last
    two columns; footer "Category" is intentionally not re-listed (already covered by main-menu).

NEW IN v1.15 (Our Story page)
  New: templates/page.our-story.json — split hero, image right (Every home has a <em>story</em>,
       no buttons) -> Why Furnisquare (inner-split with image LEFT via "Flip") -> belief quote
       (inner-quote, cream band) -> Pieces with character (inner-collections, 3 cols, plain,
       tiles: Temples / Swing Jhula / Wooden Chowki with collection links) -> CTA band
       (Begin your story — Shop now / About us).
       Live template name confirmed by client: page.our-story.json.
  inner-split.liquid gained: "Lead line" block type (.lead display type, plain text).
  inner-collections.liquid gained: "Cream band background" checkbox (default ON = current look)
    + "Columns" select (2/3/4/5/6, default 5). Bulk page unchanged.
  inner-quote.liquid gained: "Cream band background" checkbox (default OFF).
  acustom.css: .bulkcols now uses var(--cols). .lead already present.
  page.bulk-order-customization.json pins columns=5 + tint on its collections section
    (same behaviour as before; explicit for safety — re-upload it too).
  IMAGES: hero needs banner-diwan.webp, the split needs banner-bedroom.webp,
    tiles need temples.webp + swing-jhula.webp + wooden-chowki.webp —
    UPLOAD ALL FIVE to Shopify Files BEFORE assigning the template.
    (Tiles may also work via each collection's featured image: clear the Image field on a tile.)
  RE-UPLOAD: templates/page.our-story.json (NEW), sections/inner-split.liquid, inner-collections.liquid,
    inner-quote.liquid (all 3 replace), assets/acustom.css (replace), templates/page.bulk-order-customization.json (replace, pin only).

NEW IN v1.14 (Franchise page)
  New: sections/inner-facts.liquid — label/value cells in a row ("At a glance").
  New: templates/page.franchise.json — split hero (tel/mailto buttons) -> facts strip ->
       eligibility split -> what we provide (h3-only cards) -> cities pills (tint) -> CTA band.
       Live template name confirmed by client: page.franchise.json.
  inner-hero: Primary button ICON select; secondary icon select gained phone + mail.
  inner-cta: button icon selects + secondary-button new-tab checkbox.
  inner-values: card text renders only when set (h3-only cards).
  inner-pills: "Cream band background" checkbox.
  assets/acustom.css: .facts/.fact styles.
  IMAGES: living-room.webp + banner-sofa.webp must be in Shopify Files.

NEW IN v1.13 (Cancel Order page)
  New: sections/inner-cancel.liquid — retention card + real contact form (hidden Request tag).
  New: templates/page.cancel-order.json (page.cancel-order.json confirmed by client).
  inner-values: optional per-block Link label/URL + section-level Notice box; clock/cash icons.
  assets/acustom.css: .keep/.notice/.fcheck + link underlines.

NEW IN v1.12 (Contact page)
  New: sections/inner-contact-cards.liquid, sections/inner-contact-form.liquid, templates/page.contact.json.
  inner-hero: optional Facts textarea (one per line, "Label|Value").

NEW IN v1.10 / v1.9 (FAQ page) — inner-faq.liquid (16 Q&A, sticky numbered index, JSON-LD),
  templates/page.faq.json. FAQ hero must be Plain with empty buttons (or use the template).

WHAT'S INSIDE (paths mirror the theme root)
  assets/acustom.css
  snippets/inner-crumbs.liquid            (dynamic Home > page breadcrumb)
  sections/inner-hero.liquid              (page header; Facts row; button icon selects)
  sections/inner-pills.liquid             (bulk page; optional cream band)
  sections/inner-enquiry-form.liquid      (bulk page — real Shopify contact form)
  sections/inner-split.liquid             (about + bulk + franchise + our-story; Lead block; flip)
  sections/inner-collections.liquid       (bulk + our-story tiles; columns + cream band)
  sections/inner-milestones.liquid        (about page)
  sections/inner-quote.liquid             (about + our-story — belief band; optional cream band)
  sections/inner-values.liquid            (about + cancel + franchise; link/notice; h3-only cards)
  sections/inner-trust.liquid             (about + contact)
  sections/inner-cta.liquid               (espresso CTA band; icon selects)
  sections/inner-faq.liquid               (FAQ page — 16 Q&A)
  sections/inner-contact-cards.liquid     (contact page)
  sections/inner-contact-form.liquid      (contact page — real contact form)
  sections/inner-cancel.liquid            (cancel page — real contact form, cancellation request)
  sections/inner-facts.liquid             (franchise page — label/value strip)
  sections/inner-sitemap.liquid           (navigation page — menu-driven sitemap)
  sections/inner-map.liquid               (help page — Find us + Google Maps embed)
  sections/inner-reviews.liquid           (help page — review quotes band)
  sections/inner-press.liquid             (media page — press enquiry band)
  sections/inner-media.liquid             (media page — lead story + searchable coverage grid)
  templates/page.bulk-order-customization.json
  templates/page.about-us.json
  templates/page.faq.json
  templates/page.contact.json
  templates/page.cancel-order.json
  templates/page.franchise.json
  templates/page.our-story.json
  templates/page.navigation.json
  templates/page.help-contact.json
  templates/page.media-news.json

STEPS (Shopify admin with the DRAFT theme open)
  1. Online Store > Themes > Furnisquare Theme (Draft) > ... > Edit code. Upload every file above.
  2. Upload Shopify Files: banner-console.webp + banner-dining.webp (About),
     living-room.webp + banner-sofa.webp (Franchise),
     banner-diwan.webp + banner-bedroom.webp + temples.webp + swing-jhula.webp + wooden-chowki.webp (Our Story).
  3. Create templates with the SAME names the LIVE theme uses
     (bulk-order-customization, about-us, faq, contact, cancel-order, franchise, our-story, navigation, help-contact, media-news).
  4. Assign the templates to the pages; review copy in the customizer.

ICONS: values/trust/faq/contact/cancel/franchise/story icons render through snippets/icon.liquid.
  The design uses: star, shield, arrow, check, leaf, truck, card, tag, phone, wa, mail, pin, track,
  boxes, help, clock, cash, pencil.
  Missing name? icon won't render — add it in icon.liquid or pick a supported name.

NOTES
  - custom.css is untouched on purpose. All inner-page CSS lives in acustom.css, loaded AFTER custom.css.
  - Values grid: 3 cards per row; last row with 2 cards spans 3+3, last row of 1 spans full width.
  - Breadcrumb is fully dynamic (Home > {{ page.title }}).
  - Sitemap links come from Online Store > Menus (main-menu, footer-information, footer-useful-links).
  - Rollback: delete the uploaded files, or restore the theme from its backup.
