FURNISQUARE — INNER PAGES (Bulk Order + About Us + FAQ + Contact + Cancel Order + Franchise) — APPLY TO DRAFT THEME
Scope: draft theme 130907209857 ("Furnisquare Theme", Draft). DO NOT apply to the live theme.
(custom.css and every pre-existing theme file are intentionally NOT included — do not touch them.)

NEW IN v1.14 (Franchise page)
  New: sections/inner-facts.liquid — label/value cells in a row ("At a glance": floor space / investment /
       partners per city). Optional cream band; 2/3/4 columns.
  New: templates/page.franchise.json — split hero (Franchise / Open a Furnisquare experience store,
       image right, tel + mailto buttons) -> facts strip -> eligibility (inner-split, tint) ->
       "What we provide" (inner-values, h3-only cards) -> cities pills (inner-pills, tint) -> CTA band.
       Live template name confirmed by client: page.franchise.json.
  inner-hero.liquid gained: Primary button ICON select (arrow/phone/wa/mail/none, default arrow);
    Secondary icon select gained phone + mail options. All other pages unchanged (defaults reproduce current look).
  inner-cta.liquid gained: Primary button ICON select (default arrow), Secondary button ICON select
    (default none) + "Open secondary link in a new tab" checkbox. Other pages unchanged.
  inner-values.liquid gained: card text now renders ONLY when set (h3-only cards); notice + card link from v1.13 kept.
  inner-pills.liquid gained: optional cream band checkbox ("Cream band background"), default off.
  acustom.css gained the .facts/.fact styles + 900px breakpoint.
  IMAGES: hero needs living-room.webp and the eligibility split needs banner-sofa.webp —
    UPLOAD BOTH to Shopify Files (Settings or Files) BEFORE assigning the template.
  RE-UPLOAD: sections/inner-facts.liquid (NEW), inner-hero.liquid, inner-cta.liquid, inner-values.liquid,
    inner-pills.liquid (all 4 replace), assets/acustom.css (replace), templates/page.franchise.json (NEW).

NEW IN v1.13 (Cancel Order page)
  New: sections/inner-cancel.liquid — retention card (.keep) with checklist blocks + WhatsApp CTA,
       next to a real Shopify contact form (posts to the store inbox) carrying order details
       (Order ID / Full name / Phone / Email / Reason select / COD-dispatch acknowledgement checkbox)
       and a hidden "Request" tag ("Order cancellation") so you can spot these in your inbox.
  New: templates/page.cancel-order.json — hero (plain, "Cancel your <em>order</em>") -> cancel section -> Cancellation policy.
       Live template name confirmed by client: page.cancel-order.json.
  inner-values.liquid gained: optional per-block Link label + Link URL, and an optional section-level
    "Notice" html box (raw HTML allowed; rendered as the .notice banner below the cards).
  acustom.css gained the .keep / .notice / .fcheck styles + .card a / .notice a link underlines.
  RE-UPLOAD: templates/page.cancel-order.json (NEW), sections/inner-cancel.liquid (NEW),
    sections/inner-values.liquid (replace), assets/acustom.css (replace).

NEW IN v1.12 (Contact page)
  New: sections/inner-contact-cards.liquid — 4 cards (Call / WhatsApp / Email / Address); link blank = non-link card.
  New: sections/inner-contact-form.liquid — reference layout; real Shopify contact form (posts to the store inbox),
       quick-help links (Track order / Cancel / Bulk orders / FAQs) as blocks.
  New: templates/page.contact.json — hero (plain, with Facts line: Trade name | Customer care) -> cards -> form -> trust strip.
       Live template name confirmed by client: page.contact.json.
  inner-hero.liquid gained an OPTIONAL "Facts" textarea (one per line, "Label|Value").
  RE-UPLOAD: sections/inner-hero.liquid, inner-contact-cards.liquid (NEW), inner-contact-form.liquid (NEW),
    assets/acustom.css, templates/page.contact.json (NEW).

NEW IN v1.10 (FAQ sidebar fix)
  inner-faq.liquid: "All questions" index query now uses the section id.
  The FAQ page must use templates/page.faq.json, or the hero must be Plain/FAQ's with empty buttons.
NEW IN v1.9 (FAQ page)
  sections/inner-faq.liquid — sticky auto-built numbered index, help box, single-open accordion, JSON-LD.

NEW IN v1.8/v1.7/v1.6/v1.5 — heading editing: fields are "html"-type raw HTML boxes (tags visible, saved as typed;
<em>…</em> = saffron). Helper text is one short line.

EARLIER FIXES
  v1.3: inner-trust.liquid blank badge default removed (FileSaveError).
  v1.2: Inner Collections tiles — COLLECTION PICKER.

WHAT'S INSIDE (paths mirror the theme root)
  assets/acustom.css
  snippets/inner-crumbs.liquid            (dynamic Home > page breadcrumb)
  sections/inner-hero.liquid              (page header; optional Facts row; button icon selects)
  sections/inner-pills.liquid             (bulk page; optional cream band)
  sections/inner-enquiry-form.liquid      (bulk page — real Shopify contact form)
  sections/inner-split.liquid             (about + bulk + franchise pages)
  sections/inner-collections.liquid       (bulk page — collection picker tiles)
  sections/inner-milestones.liquid        (about page)
  sections/inner-quote.liquid             (about page)
  sections/inner-values.liquid            (about + cancel + franchise; optional card link + notice; h3-only cards)
  sections/inner-trust.liquid             (about + contact)
  sections/inner-cta.liquid               (espresso CTA band; icon selects)
  sections/inner-faq.liquid               (FAQ page — 16 Q&A)
  sections/inner-contact-cards.liquid     (contact page)
  sections/inner-contact-form.liquid      (contact page — real contact form)
  sections/inner-cancel.liquid            (cancel page — real contact form, cancellation request)
  sections/inner-facts.liquid             (franchise page — label/value strip)
  templates/page.bulk-order-customization.json
  templates/page.about-us.json
  templates/page.faq.json
  templates/page.contact.json
  templates/page.cancel-order.json
  templates/page.franchise.json

STEPS (Shopify admin with the DRAFT theme open)
  1. Online Store > Themes > Furnisquare Theme (Draft) > ... > Edit code. Upload every file above.
  2. Upload Shopify Files: banner-console.webp + banner-dining.webp (About),
     living-room.webp + banner-sofa.webp (Franchise).
  3. Create templates with the SAME names the LIVE theme uses
     (bulk-order-customization, about-us, faq, contact, cancel-order, franchise).
  4. Assign the templates to the pages; review copy in the customizer.

ICONS: values/trust/faq/contact/cancel/franchise icons render through the theme's snippets/icon.liquid (name-based).
  The design uses: star, shield, arrow, check, leaf, truck, card, tag, phone, wa, mail, pin, track, boxes,
  help, clock, cash, pencil.
  Missing name? icon won't render — add it in icon.liquid or pick a supported name.

NOTES
  - custom.css is untouched on purpose. All inner-page CSS lives in acustom.css, loaded AFTER custom.css.
  - Values grid: 3 cards per row; last row with 2 cards spans 3+3, last row of 1 spans full width.
  - Breadcrumb is fully dynamic (Home > {{ page.title }}).
  - Rollback: delete the uploaded files, or restore the theme from its backup.
