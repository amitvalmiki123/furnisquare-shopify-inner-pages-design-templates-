# Furnisquare — homepage, collection and product pages (static mockup for Shopify handoff)

Three pages share one header, footer and design system:

| Page | File | Shopify template |
|---|---|---|
| Homepage | `index.html` | `index` |
| Homepage V2 (cleaner, Mamta spacing) | `index-v2.html` | `index` |
| Collection: TV Units (28 products) | `collection.html` | `collection` (`/collections/tv-unit`) |
| Product: Walnora TV Cabinet | `product.html` | `product` (`/products/solid-sheesham-wood-tv-entertainment-unit`) |

## Homepage
Layout follows the client's reference, **mamtahandicraft.com**, top to bottom:
1. Full-width hero banner slideshow (5 slides, 720px tall at 1920)
2. Centred "shop by category" slider (all 42 categories, filterable)
3. Special Sale bar with countdown and bank offers, then a product slider
4. Two promo banners
5. Hot products slider
6. Featured image + text (customization, bulk, buy on phone, Amazon/Flipkart)
7. Best sellers: the live store's top 12 products by best-selling order (`src/data/bestsellers.tsv`, fetched 10 Nov 2026), with price, struck MRP and % off
8. Shop by room tiles
9. Videos
10. Trust strip and ratings
11. In the news
12. #Furnisquare gallery
13. SEO text block (Mamta style: plain headings + paragraphs, collapsed with "Read more")
14. Buying guide
15. FAQ
16. Full-width reviews
17. Footer

## Homepage V2 (10 Nov 2026)
Client asked for a cleaner V2: festive promo duo removed, more white in the middle sections, container
and spacing like mamtahandicraft.com. Measured there at 1920px: **1400px of visible content** (their
1681px container has 140px inner padding), 32px section headings, borderless product cards, cream
bands (`#f6f2ee`) between white sections. Source `src/index-v2.src.html`; styles `css/v2.css`
(scoped to `body.v2`, loaded after `style.css`, so the other pages are untouched).
V2 changes: page is white; cream bands only for Featuring, trust/ratings, buying guide and reviews;
sale bar is a light offer box instead of the dark block; reviews moved off the dark background
(only the footer is dark); **10 Nov order:** hero → ratings cards → categories (3 per row, All tab rotates tabs) → Special Sale + Best sellers → New arrivals (live newest 12, `src/data/new-arrivals.tsv`) → Featuring → Living collection (sideboards) → Shop by room (5 tiles, coffee table removed) → videos → trust → news → SEO (incl. buying guide) → FAQ → reviews. Gallery and the TV-units slider are not on V2; the "Things to consider before buying" guide is folded into the SEO text block (inside Read more) instead of its own section; headings left-aligned with a short saffron rule and an outlined
"All products" button; 4 products / 4 categories per row; 335px cards at 1920.

## Collection page (TV Units) — mamtahandicraft.com collection layout (10 Nov 2026)
Breadcrumb → plain title + live intro + quick facts (no image banner, as on Mamta's
`/collections/bedroom-furniture`) → ratings strip (same as the homepage) → one toolbar: filter
dropdowns (availability, price slider with histogram, material, finish, storage) · count · active-filter
chips · sort · 3/4 per row (default 3, like Mamta) → grid of all 28 live products, 3 large cards per row,
"Load more" 16 at a time → Shop by room → Best sellers ("What's trending") → trust strip → "Will it fit your
TV?" size tool → TV-unit buying guide behind Read more → FAQ (+ FAQPage) → reviews (same as the homepage).
Below 1280px the filters stay a slide-out drawer. Facet counts are computed from the cards.

## Product page (Walnora TV Cabinet, SKU FSQ-TC-009)
Breadcrumb → swipeable 7-image gallery (large rounded photo, "New arrival" + green "% OFF" badges, thumbnail row underneath, hover zoom, full-screen lightbox; 10 Nov client reference) →
buy box (price, MRP, saving, prepaid price, W×H×D with inch/cm switch, quantity, add to cart,
buy now, wishlist, estimated delivery dates, bank offers, warranty/customise/bulk, buy on phone,
WhatsApp, share) → ratings strip (same as the homepage) → sticky section nav → overview → full specification table (own cream band, call / WhatsApp under the intro) → dimension drawing +
"Will it fit your TV?" (dark band, as before) → delivery steps + warranty & care → trust strip → related TV units rail →
reviews (no product reviews yet, so it says so and shows real store reviews) → FAQ (+ FAQPage) →
sticky add-to-cart bar after scrolling. Product + Breadcrumb JSON-LD (no rating, since there are no reviews).

All V2 pages (homepage V2, collection, product) use **1400px** of content (`css/v2.css`, Mamta's measured width); the original `index.html` keeps 1800px (`--content` in `css/style.css`). Fonts are **Jost**
(headings) and **Inter** (body): simple, clean sans-serifs, as the client asked. Brand colours
stay Furnisquare's: logo saffron `#f28a0a`, espresso and paper.

## Content pages (18 Nov 2026)
Eight live pages rebuilt in the V2 look: `about-us`, `our-story`, `contact`, `faqs`, `navigation`,
`cancel-order`, `franchise`, `bulk-order-customization` (`.html`). Copy comes from each live
`/pages/<slug>`. Sources are `src/pages/<slug>.src.html`; they share `src/partials/page-head.html`
(title, description, canonical, BreadcrumbList schema; FAQPage schema on faqs from
`src/pages/_faqs-schema.json`). The 16 FAQs live in `src/pages/_faqs-items.html`. Styles: `css/pages.css`;
script: `js/pages.js` (FAQ index + form validation with a demo thank-you state). `build.pl` lists the
pages in `@info` and maps each `/pages/<slug>` link to its local file.

- **Forms kept** on contact, cancel-order and bulk-order: they are those pages' whole purpose on the
  live site. They post Shopify contact-form fields (`form_type=contact`). No forms on any other page.
- **Navigation** on the live site is only a name/phone/email line, so it was built as a full site map.

## Files
- `src/index.src.html`, `src/collection.src.html`, `src/product.src.html` — page sources.
  **Edit these, not the built `.html` files.**
- `src/partials/top.html` (icon sprite, top bar, header, mega menu, search) and
  `src/partials/bottom.html` (footer, floating buttons, mobile bar, toast) — shared by all pages
  via `<!--@include top-->` / `<!--@include bottom-->`.
- `src/data/categories.tsv`, `src/data/products.tsv` — the homepage's 42 category cards and 24 product cards.
- `src/data/bestsellers.tsv` — the 12 best sellers (live `/collections/all?sort_by=best-selling` order; prices and MRPs from each `products/<handle>.json`). Re-fetch when the ranking changes.
- `src/data/tv-units.tsv` — the 28 TV units (live order, prices, MRPs, delivery type, filter
  values, images). Finish/material/storage values come from each product's live title.
- `src/data/new-arrivals.tsv` — the 12 newest products (live `?sort_by=created-descending`).
- `perl build.pl` — regenerates all four pages.
- `css/style.css`, `js/script.js` — shared. `css/shop.css`, `js/shop.js` — collection + product
  pages only. `css/v2.css` — the V2 look (homepage V2, collection, product; scoped to `body.v2`). `css/shop-v2.css` — V2 fixes for the shop pages. No dependencies. Bump `?v=` in the sources when they change.
- `screenshots/` — desktop (1920) and phone (390) captures of the two new pages.
- Preview: `serve.ps1` on port 8821 (`furnisquare-website` in the root launch.json).

**Mockup links:** `build.pl` rewrites `/`, `/collections/tv-unit` and the Walnora product URL to
`index-v2.html`, `collection.html` and `product.html` so the three pages click through. Every other
link keeps its real Shopify path. Drop the `%mock_links` map at handoff.

## Client decisions
- **No forms and no map** (30 Oct 2026). This overrides the workspace standard (hero form,
  Get in Touch form, map) for this project only. Footer newsletter and search stay; both are on
  the live site. The shop filters and the TV-size tool are store controls, not lead forms.
- Layout like mamtahandicraft.com, full-size banner, 1800px container, simple clean font (30 Oct 2026).

## Content sources
Everything comes from furnisquare.com: products and prices, all 42 categories, the full mega
menu, marketplace ratings, 20K+ customers (client figure, 10 Nov 2026; the live site said 1.1M+), 36-month warranty, delivery times, press links,
real Judge.me reviews quoted word for word, and the live SEO copy. The collection's 28 products,
intro, buying guide and FAQs, and the product's description, specs, SKU, prices and 7 images,
were taken from the live store on 31 Oct 2026. Nothing was made up.

## Flags for the client
1. Hero banners are the client-supplied 2000×750 images (`images/hero/banner-*.webp`). On phones the
   wide banner is cropped to the furniture; dedicated portrait mobile banners (e.g. 800×1000) would look better.
2. The promo and best-seller banners are the client's own festive creatives with text baked in.
   They need swapping when the Diwali campaign ends.
3. Several room/product photos have filenames that match other retailers' products
   (e.g. "Brighton Oval Dining", "Harper Curved TV Console", "Aldana-2-Door-TV-Unit", Amazon `_SL1500_`
   files; on the collection page these are the hover images). The client should confirm they have the rights.
4. Logo is only 221×69px. A vector or 2× PNG is needed for sharp retina display.
5. The sale countdown ends `2026-11-08T00:00+05:30` (`data-countdown` attribute).
6. Cart, wishlist and quick-add are demo states. Wire them to the Shopify AJAX Cart API.
7. TV units 13–28 and product images 3–7 load from the Shopify CDN (`cdn.shopify.com`), so the
   mockup needs internet for those. In the theme they come from the product objects anyway.
8. **COD on this product:** every TV unit, including the Walnora, carries the live `BLOCK_COD` tag,
   so the product page doesn't promise Cash on Delivery. The top bar still says "Cash on Delivery"
   site-wide. The client should confirm which is right.
9. The Walnora's live material line isn't in its description; only the title says "Solid Sheesham Wood".
   The spec table lists only the fields the live page gives. Add material, weight and assembly if available.
10. The live collection lists 28 products "In stock" but tags 27 of them `long_delivery`. The mockup
    calls those "Made to order (25–30 days)", from the site's own FAQ. Please confirm.
11. The dimension drawing on the product page is a generic illustration, captioned as such.
12. The Cancel Order page says orders can be cancelled within **12 hours**, but FAQ #11 says **24 hours**.
    Both are copied as-is. Please confirm one figure.
13. Please confirm the contact, bulk-order and cancel-order forms should stay (the earlier brief said no forms).
