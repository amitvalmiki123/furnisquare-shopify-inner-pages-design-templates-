FURNISQUARE — INNER PAGES (Bulk Order + About Us) — APPLY TO DRAFT THEME
Scope: draft theme 130907209857 ("Furnisquare Theme", Draft). DO NOT apply to the live theme.
(custom.css and every pre-existing theme file are intentionally NOT included — do not touch them.)

IF YOU ALREADY APPLIED THE PACKAGE, THIS v1.3 BUILD FIXES:
  sections/inner-trust.liquid -> Badge text had "default": "" which Shopify rejects
    (FileSaveError: Invalid block 'item': setting with id="badge" default can't be blank).
    The default is removed; the field is just blank/optional now. Re-paste this file to fix the save error.
  sections/inner-hero.liquid -> secondary button icon picker (WhatsApp / Arrow / None; default WhatsApp = same as before)
  sections/inner-enquiry-form.liquid -> dropped accept-charset on the contact form; no visual change
  assets/acustom.css -> adds About Us styles + mobile breakpoints (bulk page visuals unchanged)
  templates/page.bulk-order-customization.json -> unchanged, re-upload not needed unless missing
  NEW: sections/inner-milestones.liquid, inner-quote.liquid, inner-values.liquid, inner-trust.liquid, inner-cta.liquid
  NEW: templates/page.about-us.json

WHAT'S INSIDE (paths mirror the theme root)
  assets/acustom.css                      -> REPLACE (inner pages stylesheet; currently empty in the theme)
  snippets/inner-crumbs.liquid            -> NEW FILE (dynamic Home > page breadcrumb)
  sections/inner-hero.liquid              -> NEW FILE (page header; reused by bulk-order + about-us)
  sections/inner-pills.liquid             -> NEW FILE
  sections/inner-enquiry-form.liquid      -> NEW FILE (real Shopify contact form)
  sections/inner-split.liquid             -> NEW FILE
  sections/inner-collections.liquid       -> NEW FILE (collection picker on tiles)
  sections/inner-milestones.liquid        -> NEW FILE (1989 / 2020 / Today)
  sections/inner-quote.liquid             -> NEW FILE (pull quote band)
  sections/inner-values.liquid            -> NEW FILE (5-card grid; bottom 2 cards render half-width each to fill the row)
  sections/inner-trust.liquid             -> NEW FILE (trust strip; reuses .trust styles from custom.css)
  sections/inner-cta.liquid               -> NEW FILE (espresso CTA band)
  templates/page.bulk-order-customization.json -> bulk page assignment
  templates/page.about-us.json            -> about-us assignment

STEPS (Shopify admin with the DRAFT theme open)
  1. Online Store > Themes > Furnisquare Theme (Draft) > ... > Edit code.
  2. Upload every file listed above to the matching path (Create asset for new files, paste/overwrite).
  3. Upload the TWO images to Shopify Files if they are not already there, keeping these exact names:
       banner-console.webp   (About hero)     — found in the repo under furnisquare-website-page-desgin/images/hero/
       banner-dining.webp    (About story)    — same folder
     (Settings -> Files. The JSON references them as shopify://shop_images/<name>.)
  4. Create the About template with the SAME name the LIVE theme uses for the About inner page.
     Check the live theme first: Online Store > Themes > LIVE > Edit code > templates/ and look for page.about*.json.
     - If live uses page.about-us.json  -> create "page.about-us" here and assign it to the About Us page.
     - If live uses a different name    -> rename templates/page.about-us.json to match and create the template with that name.
     (Bulk Order earlier was confirmed as page.bulk-order-customization.json.)
  5. The page is pre-filled with the reference design's copy. Open the page in the customizer to review;
     nothing needs manual re-entry.

HEADINGS: saffron emphasis is raw HTML in the heading fields, e.g. "Making a million homes <em>beautiful</em> since 1989".
  The customizer field SHOWS the tags; everything inside <em>...</em> renders saffron. No other HTML is needed.

ICONS: values/trust icons render through the theme's snippets/icon.liquid (name-based).
  The design uses: star, shield, arrow, check, leaf, truck, card, tag, 1989-as-text.
  If any of these names does not exist in your icon.liquid, that icon simply will not render —
  open snippets/icon.liquid, and either add the missing icon or pick a supported name in the block settings.

NOTES
  - custom.css is untouched on purpose. All inner-page CSS lives in acustom.css and is appended AFTER custom.css.
  - Values grid: 3 cards per row on desktop; with 5 cards the bottom row renders 50% + 50% filling the row
    (computed on the server from block count: last row of 2 spans 3+3, last row of 1 spans full width).
  - Breadcrumb is fully dynamic (Home > {{ page.title }}) — nothing to configure per page.
  - Rollback: delete the uploaded files, or restore the theme from its backup.
