FURNISQUARE — INNER PAGES (Bulk Order + About Us) — APPLY TO DRAFT THEME
Scope: draft theme 130907209857 ("Furnisquare Theme", Draft). DO NOT apply to the live theme.
(custom.css and every pre-existing theme file are intentionally NOT included — do not touch them.)

NEW IN v1.4 (heading editing)
  All heading fields, and the About Us quote, are now RICH TEXT fields.
  Shopify strips raw HTML (<em>) from plain text fields on save — which is why
  the tags kept disappearing and you couldn't tell which word was saffron.
  Now: select the word(s) and click the Italic (I) button — italic text renders in saffron.
  The editor shows the italic text directly, nothing is stripped, and no tags are visible.
  FILES TO RE-UPLOAD FOR THIS CHANGE (all 9 sections + both templates):
    sections/inner-hero.liquid, inner-pills.liquid, inner-enquiry-form.liquid, inner-split.liquid,
    inner-collections.liquid, inner-milestones.liquid, inner-values.liquid, inner-quote.liquid, inner-cta.liquid
    templates/page.bulk-order-customization.json, page.about-us.json
  NOTE: re-uploading the template JSONs resets any manual customizer edits on those 2 pages
  to the file defaults (the copy is identical to the reference design, so usually fine).

IF YOU ALREADY APPLIED THE PACKAGE, ALSO FIX FROM v1.3:
  sections/inner-trust.liquid -> removed blank "default": "" on Badge text
    (FileSaveError: setting with id="badge" default can't be blank). Field is simply optional now.

WHAT'S INSIDE (paths mirror the theme root)
  assets/acustom.css                      -> REPLACE (inner pages stylesheet; currently empty in the theme)
  snippets/inner-crumbs.liquid            -> NEW FILE (dynamic Home > page breadcrumb)
  sections/inner-hero.liquid              -> NEW FILE (page header; reused by bulk-order + about-us)
  sections/inner-pills.liquid             -> NEW FILE
  sections/inner-enquiry-form.liquid      -> NEW FILE (real Shopify contact form)
  sections/inner-split.liquid             -> NEW FILE
  sections/inner-collections.liquid       -> NEW FILE (collection picker on tiles)
  sections/inner-milestones.liquid        -> NEW FILE (1989 / 2020 / Today)
  sections/inner-quote.liquid             -> NEW FILE (pull quote band)
  sections/inner-values.liquid            -> NEW FILE (5-card grid; bottom 2 cards render half-width each to fill the row)
  sections/inner-trust.liquid             -> NEW FILE (trust strip; reuses .trust styles from custom.css)
  sections/inner-cta.liquid               -> NEW FILE (espresso CTA band)
  templates/page.bulk-order-customization.json -> bulk page assignment
  templates/page.about-us.json            -> about-us assignment

STEPS (Shopify admin with the DRAFT theme open)
  1. Online Store > Themes > Furnisquare Theme (Draft) > ... > Edit code.
  2. Upload every file listed above to the matching path (Create asset for new files, paste/overwrite).
  3. Upload the TWO images to Shopify Files if they are not already there, keeping these exact names:
       banner-console.webp   (About hero)     — found in the repo under furnisquare-website-page-desgin/images/hero/
       banner-dining.webp    (About story)    — same folder
     (Settings -> Files. The JSON references them as shopify://shop_images/<name>.)
  4. Create the About template with the SAME name the LIVE theme uses for the About inner page.
     Check the live theme first: Online Store > Themes > LIVE > Edit code > templates/ and look for page.about*.json.
  5. The page is pre-filled with the reference design's copy. Open the page in the customizer to review;
     nothing needs manual re-entry.

ICONS: values/trust icons render through the theme's snippets/icon.liquid (name-based).
  The design uses: star, shield, arrow, check, leaf, truck, card, tag, 1989-as-text.
  If any of these names does not exist in your icon.liquid, that icon simply will not render —
  either add the missing icon there or pick a supported name in the block settings.

NOTES
  - custom.css is untouched on purpose. All inner-page CSS lives in acustom.css and is appended AFTER custom.css.
  - Values grid: 3 cards per row on desktop; with 5 cards the bottom row renders 50% + 50% filling the row
    (computed from block count: last row of 2 spans 3+3, last row of 1 spans full width).
  - Breadcrumb is fully dynamic (Home > {{ page.title }}) — nothing to configure per page.
  - Rollback: delete the uploaded files, or restore the theme from its backup.
