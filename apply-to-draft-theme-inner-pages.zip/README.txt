FURNISQUARE — INNER PAGES (Bulk Order + About Us + FAQ + Contact + Cancel Order) — APPLY TO DRAFT THEME
Scope: draft theme 130907209857 ("Furnisquare Theme", Draft). DO NOT apply to the live theme.
(custom.css and every pre-existing theme file are intentionally NOT included — do not touch them.)

NEW IN v1.13 (Cancel Order page)
  New: sections/inner-cancel.liquid — retention card (.keep) with checklist blocks + WhatsApp CTA,
       next to a real Shopify contact form (posts to the store inbox) carrying order details
       (Order ID / Full name / Phone / Email / Reason select / COD-dispatch acknowledgement checkbox)
       and a hidden "Request" tag ("Order cancellation") so you can spot these in your inbox.
  New: templates/page.cancel-order.json — hero (plain, "Cancel your <em>order</em>") -> cancel section -> Cancellation policy.
       Live template name confirmed by client: page.cancel-order.json.
  inner-values.liquid gained: optional per-block Link label + Link URL, and an optional section-level
    "Notice" html box (raw HTML allowed; rendered as the .notice banner below the cards).
    Used by the policy section (link "Customize order policy" inside the card text); About page unaffected (both blank).
  inner-values.liquid icons gained: clock, cash (policy cards).
  acustom.css gained the .keep / .notice / .fcheck styles + .card a / .notice a link underlines. Phead Facts CSS already present.
  No new images. RE-UPLOAD: templates/page.cancel-order.json (NEW), sections/inner-cancel.liquid (NEW),
    sections/inner-values.liquid (replace), assets/acustom.css (replace).
    (inner-hero.liquid already re-uploaded in v1.12 — content unchanged this version.)

NEW IN v1.12 (Contact page)
  New: sections/inner-contact-cards.liquid — 4 cards (Call / WhatsApp / Email / Address); link blank = non-link card.
  New: sections/inner-contact-form.liquid — reference layout; real Shopify contact form (posts to the store inbox),
       quick-help links (Track order / Cancel / Bulk orders / FAQs) as blocks.
  New: templates/page.contact.json — hero (plain, with Facts line: Trade name | Customer care) -> cards -> form -> trust strip.
       Live template name confirmed by client: page.contact.json.
  inner-hero.liquid gained an OPTIONAL "Facts" textarea (one per line, "Label|Value") — used by the Contact hero; other pages unaffected.
  acustom.css gained the .ccards/.quick styles + mobile breakpoints.
  No new images. RE-UPLOAD: sections/inner-hero.liquid, inner-contact-cards.liquid (NEW), inner-contact-form.liquid (NEW),
    assets/acustom.css, templates/page.contact.json (NEW).

NEW IN v1.10 (FAQ sidebar fix)
  inner-faq.liquid: "All questions" index query now uses the section id (was currentScript.closest → always null).
  The FAQ page must use templates/page.faq.json (upload it), or the hero must be set to Plain/FAQ's with empty buttons.
NEW IN v1.9 (FAQ page)
  sections/inner-faq.liquid — sticky auto-built numbered index, help box (theme settings), single-open accordion, JSON-LD.
  templates/page.faq.json. The theme's own faq.liquid is UNTOUCHED.

NEW IN v1.8/v1.7/v1.6/v1.5 — heading editing: fields are "html"-type raw HTML boxes (tags visible, saved as typed;
<em>…</em> = saffron). Labels show the tag: "Heading (H1)" / "(H2)" / "Form heading (H2)" / "Title (H3)" / "Quote (blockquote)".
Helper text is one short line. Stray richtext-era <p>…</p> wrappers are stripped at render time.

EARLIER FIXES
  v1.3: inner-trust.liquid blank badge default removed (FileSaveError).
  v1.2: Inner Collections tiles — COLLECTION PICKER; Name/Image/Alt fall back to the collection.

WHAT'S INSIDE (paths mirror the theme root)
  assets/acustom.css
  snippets/inner-crumbs.liquid            (dynamic Home > page breadcrumb)
  sections/inner-hero.liquid              (page header used by all pages; optional Facts row)
  sections/inner-pills.liquid             (bulk page)
  sections/inner-enquiry-form.liquid      (bulk page — real Shopify contact form)
  sections/inner-split.liquid             (about + bulk pages)
  sections/inner-collections.liquid       (bulk page — collection picker tiles)
  sections/inner-milestones.liquid        (about page)
  sections/inner-quote.liquid             (about page)
  sections/inner-values.liquid            (about + cancel pages — last row fills exactly; optional card link + notice)
  sections/inner-trust.liquid             (about + contact — reuses .trust styles from custom.css)
  sections/inner-cta.liquid               (espresso CTA band; bulk + faq pages)
  sections/inner-faq.liquid               (FAQ page — 16 Q&A)
  sections/inner-contact-cards.liquid     (contact page)
  sections/inner-contact-form.liquid      (contact page — real contact form)
  sections/inner-cancel.liquid            (cancel page — real contact form, cancellation request)
  templates/page.bulk-order-customization.json
  templates/page.about-us.json
  templates/page.faq.json
  templates/page.contact.json
  templates/page.cancel-order.json

STEPS (Shopify admin with the DRAFT theme open)
  1. Online Store > Themes > Furnisquare Theme (Draft) > ... > Edit code. Upload every file above.
  2. Upload banner-console.webp + banner-dining.webp to Shopify Files if missing (About page).
  3. Create templates with the SAME names the LIVE theme uses
     (bulk-order-customization, about-us, faq, contact, cancel-order).
  4. Assign the templates to the pages; review copy in the customizer.

ICONS: values/trust/faq/contact/cancel icons render through the theme's snippets/icon.liquid (name-based).
  The design uses: star, shield, arrow, check, leaf, truck, card, tag, phone, wa, mail, pin, track, boxes,
  help, clock, cash, pencil.
  Missing name? icon won't render — add it in icon.liquid or pick a supported name.

NOTES
  - custom.css is untouched on purpose. All inner-page CSS lives in acustom.css, loaded AFTER custom.css.
  - Values grid: 3 cards per row; last row with 2 cards spans 3+3, last row of 1 spans full width.
  - Breadcrumb is fully dynamic (Home > {{ page.title }}).
  - Cancellation form is a real Shopify contact form: submissions land in the store inbox with the
    "Order cancellation" tag (contact[Request]); the checkbox and phone pattern are enforced natively.
  - Rollback: delete the uploaded files, or restore the theme from its backup.
