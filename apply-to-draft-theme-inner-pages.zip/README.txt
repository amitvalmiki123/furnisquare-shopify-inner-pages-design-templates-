FURNISQUARE — INNER PAGES (Bulk Order + About Us + FAQ) — APPLY TO DRAFT THEME
Scope: draft theme 130907209857 ("Furnisquare Theme", Draft). DO NOT apply to the live theme.
(custom.css and every pre-existing theme file are intentionally NOT included — do not touch them.)

NEW IN v1.9 (FAQ page)
  New: sections/inner-faq.liquid — sidebar "All questions" index (auto-built, numbered, sticky),
       help box (phone + WhatsApp from THEME SETTINGS — same as the rest of the theme), single-open
       accordion, FAQPage JSON-LD for SEO. Pre-filled with the mockup's 16 Q&A as both the
       section preset and the template content.
  New: templates/page.faq.json — hero (plain, no buttons) -> faq -> CTA ("Didn't find your answer?").
  acustom.css gained the FAQ styles (index counter, help box, list markers, mobile breakpoints).
  NOTE: the theme's own faq.liquid (collection-page accordion) is UNTOUCHED — this page uses the new section.
  No new images. Create the "page.faq" template in the draft theme and assign the FAQ page to it
  (user confirmed the live template name is page.faq.json).
  RE-UPLOAD for the FAQ page: sections/inner-faq.liquid (NEW), assets/acustom.css, templates/page.faq.json (NEW),
  plus re-paste the existing 10 sections if you want the latest info-text/labels.

NEW IN v1.8 (clean fields)
  Helper text under headings/quote reduced to one short line: "Saffron = wrap text in <em>…</em>".
NEW IN v1.7 (stray <p> tags in stored heading values)
  Render strips stray <p> tags. To clean the FIELDS: delete leading <p>/trailing </p> per field,
  or re-upload the template JSONs (resets customizer edits — only if none were made).
NEW IN v1.6 (heading levels visible in the customizer)
  Labels show the storefront tag: "Heading (H1)" / "(H2)" / "Form heading (H2)" / "Title (H3)" / "Quote (blockquote)".
NEW IN v1.5 (heading editing)
  Heading fields (and the About Us quote) are "html"-type settings: raw HTML box, tags visible & saved as typed.
  Text inside <em>...</em> renders in saffron on the storefront.

EARLIER FIXES
  v1.3: inner-trust.liquid blank badge default removed (FileSaveError).
  v1.2: Inner Collections tiles — COLLECTION PICKER; Name/Image/Alt fall back to the collection.

WHAT'S INSIDE (paths mirror the theme root)
  assets/acustom.css
  snippets/inner-crumbs.liquid            (dynamic Home > page breadcrumb)
  sections/inner-hero.liquid              (page header; reused by the 3 pages)
  sections/inner-pills.liquid             (bulk page)
  sections/inner-enquiry-form.liquid      (bulk page — real Shopify contact form)
  sections/inner-split.liquid             (about + bulk pages)
  sections/inner-collections.liquid       (bulk page — collection picker tiles)
  sections/inner-milestones.liquid        (about page)
  sections/inner-quote.liquid             (about page)
  sections/inner-values.liquid            (about page — last row fills exactly)
  sections/inner-trust.liquid             (about page — reuses .trust styles from custom.css)
  sections/inner-cta.liquid               (expresso CTA band; all 3 pages)
  sections/inner-faq.liquid               (FAQ page — 16 Q&A)
  templates/page.bulk-order-customization.json
  templates/page.about-us.json
  templates/page.faq.json

STEPS (Shopify admin with the DRAFT theme open)
  1. Online Store > Themes > Furnisquare Theme (Draft) > ... > Edit code. Upload every file above.
  2. Upload banner-console.webp + banner-dining.webp to Shopify Files if missing (About page).
     Settings -> Files; found in the repo under furnisquare-website-page-desgin/images/hero/
  3. Create templates with the SAME names the LIVE theme uses:
       page.bulk-order-customization (confirmed), page.about-us (check live), page.faq (confirmed).
  4. Assign the templates to the pages; review copy in the customizer.

ICONS: values/trust/faq icons render through the theme's snippets/icon.liquid (name-based).
  The design uses: star, shield, arrow, check, leaf, truck, card, tag, phone, wa, 1989-as-text.
  Missing name? icon won't render — add it in icon.liquid or pick a supported name.

NOTES
  - custom.css is untouched on purpose. All inner-page CSS lives in acustom.css and is appended AFTER custom.css.
  - Values grid: 3 cards per row; last row with 2 cards spans 3+3, last row of 1 spans full width.
  - Breadcrumb is fully dynamic (Home > {{ page.title }}) — nothing to configure per page.
  - Rollback: delete the uploaded files, or restore the theme from its backup.
