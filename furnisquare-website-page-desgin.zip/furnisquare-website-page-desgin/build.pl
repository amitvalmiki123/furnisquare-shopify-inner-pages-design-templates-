#!/usr/bin/perl
# Assembles the static pages from src/:
#   index.html       <- src/index.src.html       (42 category tiles, 24 product cards)
#   index-v2.html    <- src/index-v2.src.html    (V2 concept: same blocks, css/v2.css on top)
#   collection.html  <- src/collection.src.html  (TV Units: 28 product cards)
#   product.html     <- src/product.src.html     (Walnora TV Cabinet + related rail)
# Header/footer live once in src/partials/{top,bottom}.html (<!--@include name-->).
# Repeating blocks are generated from src/data/*.tsv so labels, handles and prices live in one place.
# Run:  perl build.pl
use strict; use warnings; use utf8;
use open qw(:std :encoding(UTF-8));

my $root = $0 =~ s{[^/\\]+$}{}r || './';

sub read_tsv {
  my ($file) = @_;
  open my $fh, '<', "$root$file" or die "$file: $!";
  my $head = <$fh>; chomp $head; $head =~ s/\r//; my @cols = split /\t/, $head;
  my @rows;
  while (my $l = <$fh>) {
    chomp $l; $l =~ s/\r//; next unless length $l;
    my %r; @r{@cols} = split /\t/, $l; push @rows, \%r;
  }
  return @rows;
}
sub slurp { my $f = shift; open my $fh, '<', "$root$f" or die "$f: $!"; local $/; <$fh> }
sub esc { my $s = shift; $s =~ s/&/&amp;/g; $s =~ s/</&lt;/g; $s =~ s/"/&quot;/g; $s }
sub num { my $s = shift; $s =~ s/,//g; $s }
# Indian digit grouping: 135999 -> 1,35,999
sub inr { my $s = shift; return $s if length $s <= 3; my ($rest, $last) = ($s =~ /^(\d+)(\d{3})$/); $rest =~ s/(\d)(?=(\d\d)+$)/$1,/g; "$rest,$last" }

# Image files are named by handle, except the dining-chairs tile.
my %img_override = ('chairs-1' => 'dining-chairs');
my %group_label  = (dining => 'Dining', bedroom => 'Bedroom', living => 'Living',
                    storage => 'Storage & Study', heritage => 'Heritage & Decor');

my @cats = read_tsv('src/data/categories.tsv');
# The "All" view rotates through the tabs (living, bedroom, dining, storage, heritage) so neighbouring
# cards are always different kinds of furniture. Each tab keeps its own TSV order.
my @group_order = qw(living bedroom dining storage heritage);
my %by_group; push @{ $by_group{$_->{group}} }, $_ for @cats;
my @cats_rr;
while (grep { @{ $by_group{$_} || [] } } @group_order) {
  for my $g (@group_order) { push @cats_rr, shift @{ $by_group{$g} } if @{ $by_group{$g} || [] }; }
}
die "category rotation lost items" unless @cats_rr == @cats;
my $cat_html = '';
for my $c (@cats_rr) {
  my $img   = $img_override{$c->{slug}} // $c->{slug};
  my $label = esc($c->{label});
  $cat_html .= <<"HTML";
          <li class="cat" data-group="$c->{group}">
            <a class="cat__link" href="/collections/$c->{slug}">
              <span class="cat__media"><img src="images/cats/$img.webp" alt="$label from Furnisquare's solid wood range" width="600" height="600" loading="lazy" decoding="async"></span>
              <span class="cat__tag">Sale live</span>
              <span class="cat__name">$label <small>$group_label{$c->{group}}</small></span>
            </a>
          </li>
HTML
}
die "expected 42 categories, got " . scalar(@cats) unless @cats == 42;

# Live-store product lists (price + MRP from each products/<handle>.json):
#   best sellers  = top 12 of /collections/all?sort_by=best-selling      -> src/data/bestsellers.tsv
#   new arrivals  = top 12 of /collections/all?sort_by=created-descending -> src/data/new-arrivals.tsv
# $label overrides the badge (e.g. "New"); without it the badge shows the % off.
sub live_cards {
  my ($file, $label) = @_;
  my @rows = read_tsv($file);
  die "expected 12 products in $file, got " . scalar(@rows) unless @rows == 12;
  my $html = '';
  for my $p (@rows) {
  my $t = esc($p->{title});
  my $off = $p->{mrp} > $p->{price} ? int(($p->{mrp} - $p->{price}) / $p->{mrp} * 100 + .5) : 0;
  my $tag = $label // ($off ? "$off% off" : 'Best seller');
  my $mrp = $off ? ' <s><span class="sr-only">MRP </span>₹' . inr($p->{mrp}) . '</s>' : '';
  $html .= <<"HTML";
            <li class="pcard">
              <a class="pcard__media" href="/products/$p->{handle}" tabindex="-1" aria-hidden="true">
                <img class="pcard__img" src="images/products/$p->{id}-a.webp" alt="" width="800" height="800" loading="lazy" decoding="async">
                <img class="pcard__img pcard__img--alt" src="images/products/$p->{id}-b.webp" alt="" loading="lazy" decoding="async">
              </a>
              <span class="pcard__tag">$tag</span>
              <button class="pcard__wish" type="button" aria-pressed="false" aria-label="Add $t to wishlist"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20.5s-7.5-4.6-7.5-10.3A4.2 4.2 0 0 1 12 7.6a4.2 4.2 0 0 1 7.5 2.6c0 5.7-7.5 10.3-7.5 10.3Z"/></svg></button>
              <div class="pcard__body">
                <h3 class="pcard__title"><a href="/products/$p->{handle}">$t</a></h3>
                <p class="pcard__price"><span class="sr-only">Price </span>₹@{[ inr($p->{price}) ]}$mrp</p>
                <button class="pcard__add" type="button" data-add="$t">Add to cart <span aria-hidden="true">+</span></button>
              </div>
            </li>
HTML
  }
  return $html;
}
my $best_html = live_cards('src/data/bestsellers.tsv');
my $new_html  = live_cards('src/data/new-arrivals.tsv', 'New');

my @prods = read_tsv('src/data/products.tsv');
my %cards = (tv => '', sb => '');
for my $p (@prods) {
  my ($set) = $p->{id} =~ /^(tv|sb)/;
  my $t = esc($p->{title});
  my $review = $p->{id} eq 'sb-01' ? qq{\n                  <p class="pcard__rating"><span aria-hidden="true">★★★★★</span> 1 review</p>} : '';
  $cards{$set} .= <<"HTML";
            <li class="pcard">
              <a class="pcard__media" href="/products/$p->{handle}" tabindex="-1" aria-hidden="true">
                <img class="pcard__img" src="images/products/$p->{id}-a.webp" alt="" width="800" height="819" loading="lazy" decoding="async">
                <img class="pcard__img pcard__img--alt" src="images/products/$p->{id}-b.webp" alt="" loading="lazy" decoding="async">
              </a>
              <span class="pcard__tag">Sale live</span>
              <button class="pcard__wish" type="button" aria-pressed="false" aria-label="Add $t to wishlist"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20.5s-7.5-4.6-7.5-10.3A4.2 4.2 0 0 1 12 7.6a4.2 4.2 0 0 1 7.5 2.6c0 5.7-7.5 10.3-7.5 10.3Z"/></svg></button>
              <div class="pcard__body">
                <h3 class="pcard__title"><a href="/products/$p->{handle}">$t</a></h3>$review
                <p class="pcard__price"><span class="sr-only">Price </span>₹$p->{price}</p>
                <button class="pcard__add" type="button" data-add="$t">Add to cart <span aria-hidden="true">+</span></button>
              </div>
            </li>
HTML
}

# ---------- TV Units collection (live order = "featured") ----------
my @tv = read_tsv('src/data/tv-units.tsv');
die "expected 28 TV units, got " . scalar(@tv) unless @tv == 28;
sub tv_card {
  my ($p, $pos, $indent) = @_;
  my $t = esc($p->{title});
  my ($price, $mrp) = (num($p->{price}), num($p->{compare}));
  my $off = int((1 - $price / $mrp) * 100 + .5);
  my $save = inr($mrp - $price);
  my $badge = $p->{delivery} eq 'ready'
    ? '<span class="pcard__chip pcard__chip--ready">Ready to ship</span>'
    : '<span class="pcard__chip">Made to order</span>';
  my $eta = $p->{delivery} eq 'ready' ? '7–10 business days' : '25–30 days';
  my $html = <<"HTML";
<li class="pcard pcard--shop" data-pos="$pos" data-price="$price" data-off="$off" data-delivery="$p->{delivery}" data-material="$p->{material}" data-finish="$p->{finish}" data-storage="$p->{storage}">
  <a class="pcard__media" href="/products/$p->{handle}" tabindex="-1" aria-hidden="true">
    <img class="pcard__img" src="$p->{img_a}" alt="" width="800" height="819" loading="lazy" decoding="async">
    <img class="pcard__img pcard__img--alt" src="$p->{img_b}" alt="" loading="lazy" decoding="async">
  </a>
  <span class="pcard__tag">$off% off</span>
  <button class="pcard__wish" type="button" aria-pressed="false" aria-label="Add $t to wishlist"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20.5s-7.5-4.6-7.5-10.3A4.2 4.2 0 0 1 12 7.6a4.2 4.2 0 0 1 7.5 2.6c0 5.7-7.5 10.3-7.5 10.3Z"/></svg></button>
  <div class="pcard__body">
    $badge
    <h3 class="pcard__title"><a href="/products/$p->{handle}">$t</a></h3>
    <p class="pcard__price"><span class="sr-only">Sale price </span>₹$p->{price} <s><span class="sr-only">Regular price </span>₹$p->{compare}</s></p>
    <p class="pcard__meta">You save ₹$save · Delivery $eta</p>
    <button class="pcard__add" type="button" data-add="$t">Add to cart <span aria-hidden="true">+</span></button>
  </div>
</li>
HTML
  $html =~ s/^/$indent/mg;
  return $html;
}
my ($grid_html, $related_html) = ('', '');
my $pos = 0;
for my $p (@tv) { $grid_html .= tv_card($p, ++$pos, '          '); }
# Related rail on the product page: the other ready-made images we hold locally (tv-02 … tv-12)
for my $p (grep { $_->{id} ne 'tv-01' && $_->{img_a} =~ /^images\// } @tv) { $related_html .= tv_card($p, 0, '        '); }

# Mockup-only links so the three pages click through; Shopify routes replace them on handoff.
my %mock_links = (
  '/collections/tv-unit' => 'collection.html',
  '/products/solid-sheesham-wood-tv-entertainment-unit' => 'product.html',
  '/' => 'index-v2.html',   # V2 is the current homepage; the collection/product pages use the V2 look
);

# Content pages (18 Nov): built from src/pages/<slug>.src.html with the shared head in
# src/partials/page-head.html. Text comes from the live /pages/<slug> URL.
my @info = (
  ['about-us',                 'About Us',               'About Us – Furnisquare | Jangid Handicrafts since 1989',
   'Furnisquare began as Jangid Handicrafts in 1989 with 35 designs and a vision to make a million homes beautiful. Our story and the values behind every piece.'],
  ['our-story',                'Our Story',              'Our Story – Furniture with Character | Furnisquare',
   'Every home has a story. Why we created Furnisquare: quality home furnishings filled with character, made to be handed down.'],
  ['contact',                  'Contact',                'Contact Furnisquare – Phone, WhatsApp & Email',
   'Contact Furnisquare on +91-9785322576 or info@furnisquare.com. Questions about products, orders, customisation or bulk buying — our team is here to help.'],
  ['franchise',                'Franchise',              'Furnisquare Franchise – Open an Experience Store',
   'Partner with Furnisquare: experience stores of 1,500–10,000 sq. ft. in Delhi, Mumbai, Ahmedabad, Surat, Jaipur, Pune, Hyderabad, Bengaluru, Chennai, Vizag and Kolkata.'],
  ['faqs',                     'FAQs',                   'FAQs – Shipping, Payment, Delivery & Warranty | Furnisquare',
   'Answers to common questions about free shipping, Cash on Delivery, delivery times, assembly, cancellations, refunds, custom orders and the 36-month warranty.'],
  ['navigation',               'Navigation',             'Site Navigation – All Furnisquare Categories & Pages',
   'Every Furnisquare category and page in one place: sofas, living room, bedroom, dining, storage, study and decor, plus help and policy pages.'],
  ['cancel-order',             'Cancel Order',           'Cancel Your Order – Furnisquare',
   'Request a cancellation for your Furnisquare order. Orders can only be cancelled within 12 hours after placing the order.'],
  ['bulk-order-customization', 'Bulk Order & Customization', 'Bulk Orders & Custom Furniture – Furnisquare',
   'Bulk furniture for retailers, wholesalers, interior designers, architects, hotels, offices and distributors. Our team will contact you within 24 hours with a customised catalogue and quotation.'],
);
my %info_head;
my $page_head = slurp('src/partials/page-head.html');
my $faq_schema = slurp('src/pages/_faqs-schema.json');
my $faq_items  = slurp('src/pages/_faqs-items.html');
for my $i (@info) {
  my ($slug, $crumb, $title, $desc) = @$i;
  $mock_links{"/pages/$slug"} = "$slug.html";
  my $head = $page_head;
  my $extra = $slug eq 'faqs' ? ",\n      {\n        \"\@type\": \"FAQPage\",\n        \"mainEntity\": [\n$faq_schema        ]\n      }" : '';
  my %v = (title => esc($title), desc => esc($desc), path => "/pages/$slug", crumb => esc($crumb), schema_extra => $extra);
  $head =~ s/\{\{(\w+)\}\}/$v{$1}/g;
  $info_head{"$slug.html"} = $head;
}

my $top    = slurp('src/partials/top.html');
my $bottom = slurp('src/partials/bottom.html');
my %pages = (
  'index.html'      => { src => 'src/index.src.html',      shop => '#categories',
                         blocks => { cats => $cat_html, 'products-tv' => $cards{tv}, 'products-sb' => $cards{sb}, 'products-best' => $best_html } },
  # V2 homepage concept (1400px content, white middle sections, no promo duo) — css/v2.css on top of style.css
  # V2 order (10 Nov): ratings after hero, best sellers in the sale section, new arrivals, living collection
  'index-v2.html'   => { src => 'src/index-v2.src.html',   shop => '#categories',
                         blocks => { cats => $cat_html, 'products-best' => $best_html, 'products-new' => $new_html, 'products-sb' => $cards{sb} } },
  'collection.html' => { src => 'src/collection.src.html', shop => '#grid',
                         blocks => { 'tv-grid' => $grid_html, 'products-best' => $best_html } },
  'product.html'    => { src => 'src/product.src.html',    shop => 'collection.html',
                         blocks => { related => $related_html } },
  (map { ("$_->[0].html" => { src => "src/pages/$_->[0].src.html", shop => 'collection.html',
                              blocks => ($_->[0] eq 'faqs' ? { 'faq-items' => $faq_items } : {}) }) } @info),
);

for my $out (sort keys %pages) {
  my $pg  = $pages{$out};
  my $src = slurp($pg->{src});
  $src =~ s/<!--\@include page-head-->\n?/$info_head{$out}/ if $info_head{$out};
  $src =~ s/<!--\@include top-->\n?/$top/;
  $src =~ s/<!--\@include bottom-->\n?/$bottom/;
  $src =~ s/\{\{shop\}\}/$pg->{shop}/g;
  for my $k (keys %{ $pg->{blocks} }) { $src =~ s/<!--\@\Q$k\E-->\n?/$pg->{blocks}{$k}/ or die "$out: no <!--\@$k--> marker"; }
  die "$out: unreplaced marker" if $src =~ /<!--\@/;
  for my $from (keys %mock_links) { $src =~ s/href="\Q$from\E"/href="$mock_links{$from}"/g; }
  open my $fh, '>', "$root$out" or die $!;
  print $fh $src;
  close $fh;
  print "$out written\n";
}
printf "%d categories, %d homepage products, %d TV units\n", scalar(@cats), scalar(@prods), scalar(@tv);
