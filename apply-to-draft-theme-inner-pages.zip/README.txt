FURNISQUARE — INNER PAGES (Bulk Order + About Us + FAQ) — APPLY TO DRAFT THEME
Scope: draft theme 130907209857 ("Furnisquare Theme", Draft). DO NOT apply to the live theme.
(custom.css and every pre-existing theme file are intentionally NOT included — do not touch them.)

NEW IN v1.10 (FAQ sidebar fix)
  sections/inner-faq.liquid: the "All questions" index stayed empty because the inline script
  looked up the section with document.currentScript.closest('.faq') — the script is a SIBLING of the
  section, not a child, so it returned null. Now it queries the section by id; the 01–16 numbered
  index renders exactly like the mockup. RE-UPLOAD: sections/inner-faq.liquid only.

IMPORTANT FOR THE FAQ PAGE
  If you created the template in the editor and ADDED THE SECTIONS MANUALLY, the hero is showing the
  DEFAULT settings ("Enquiry for bulk orders" + saffron "Send an enquiry" and "WhatsApp us" buttons).
  To match the reference design either:
    1. Edit code > templates/page.faq.json — paste this zip's templates/page.faq.json contents
       (replaces current file; the page holds only defaults, nothing manual to lose), OR
    2. In the editor, open the Inner Page Hero section and set: Layout = Plain, Eyebrow = FAQ's,
       Heading = Frequently asked <em>questions</em>, Lede = Shipping, payment, delivery times,
       assembly, cancellations, refunds and warranty — everything customers ask us most, in one place.
       Then CLEAR both button labels (delete the text).

NEW IN v1.9 (FAQ page)
  New: sections/inner-faq.liquid — sidebar "All questions" index (auto-built, numbered, sticky),
       help box (phone + WhatsApp from THEME SETTINGS), single-open accordion, FAQPage JSON-LD.
       Pre-filled with the mockup's 16 Q&A (section preset + template content).
  New: templates/page.faq.json — hero (plain, no buttons) -> faq -> CTA ("Didn't find your answer?").
  acustom.css gained the FAQ styles. The theme's own faq.liquid (collection accordion) is UNTOUCHED.
  No new images. Live template name confirmed by client: page.faq.json.

NEW IN v1.8/v1.7/v1.6/v1.5 — heading editing: fields are "html"-type raw HTML boxes (tags visible,
saved as typed; <em>…</em> = saffron). Labels show the tag: "Heading (H1)" / "(H2)" / "Form heading (H2)" /
"Title (H3)" / "Quote (blockquote)". Helper text is one short line. Stray richtext-era <p>…</p>
wrappers in stored values are stripped at render time. To clean the FIELDS: delete leading <p> and
trailing </p>, or re-upload the template JSONs (resets customizer edits).

EARLIER FIXES
  v1.3: inner-trust.liquid blank badge default removed (FileSaveError).
  v1.2: Inner Collections tiles — COLLECTION PICKER; Name/Image/Alt fall back to the collection.

WHAT'S INSIDE (paths mirror the theme root)
  assets/acustom.css
  snippets/inner-crumbs.liquid            (dynamic Home > page breadcrumb)
  sections/inner-hero.liquid              (page header; reused by the 3 pages)
  sections/inner-pills.liquid             (bulk page)
  sections/inner-enquiry-form.liquid      (bulk page — real Shopify contact form)
  sections/inner-split.liquid             (about + bulk pages)
  sections/inner-collections.liquid       (bulk page — collection picker tiles)
  sections/inner-milestones.liquid        (about page)
  sections/inner-quote.liquid             (about page)
  sections/inner-values.liquid            (about page — last row fills exactly)
  sections/inner-trust.liquid             (about page — reuses .trust styles from custom.css)
  sections/inner-cta.liquid               (espresso CTA band; all 3 pages)
  sections/inner-faq.liquid               (FAQ page — 16 Q&A)
  templates/page.bulk-order-customization.json
  templates/page.about-us.json
  templates/page.faq.json

STEPS (Shopify admin with the DRAFT theme open)
  1. Online Store > Themes > Furnisquare Theme (Draft) > ... > Edit code. Upload every file above.
  2. Upload banner-console.webp + banner-dining.webp to Shopify Files if missing (About page).
  3. Create templates with the SAME names the LIVE theme uses (bulk-order-customization, about-us, faq).
  4. Assign the templates to the pages; review copy in the customizer.

ICONS: values/trust/faq icons render through the theme's snippets/icon.liquid (name-based).
  Missing name? icon won't render — add it in icon.liquid or pick a supported name.

NOTES
  - custom.css is untouched on purpose. All inner-page CSS lives in acustom.css, loaded AFTER custom.css.
  - Values grid: 3 cards per row; last row with 2 cards spans 3+3, last row of 1 spans full width.
  - Breadcrumb is fully dynamic (Home > {{ page.title }}).
  - Rollback: delete the uploaded files, or restore the theme from its backup.
