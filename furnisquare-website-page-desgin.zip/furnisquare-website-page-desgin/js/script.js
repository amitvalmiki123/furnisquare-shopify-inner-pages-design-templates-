/* Furnisquare homepage — vanilla JS, no dependencies. */
(function () {
  'use strict';

  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var desktopNav = window.matchMedia('(min-width: 1280px)');

  /* ---------- toast ---------- */
  var toastEl = $('.toast'), toastTimer;
  function toast(msg) {
    if (!toastEl) return;
    toastEl.textContent = msg;
    toastEl.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.hidden = true; }, 2600);
  }

  /* ---------- topbar announcement rotation ---------- */
  var news = $$('.topbar__news p'), newsIdx = 0;
  if (news.length > 1 && !reduceMotion) {
    setInterval(function () {
      var cur = news[newsIdx];
      cur.classList.remove('is-on'); cur.classList.add('is-out');
      newsIdx = (newsIdx + 1) % news.length;
      news[newsIdx].classList.remove('is-out'); news[newsIdx].classList.add('is-on');
      setTimeout(function () { cur.classList.remove('is-out'); }, 700);
    }, 4200);
  }

  /* ---------- sticky header shadow + floating call button ---------- */
  var hdr = $('.hdr'), floatCall = $('.float-call');
  function onScrollChrome() {
    var y = window.scrollY;
    hdr.classList.toggle('is-stuck', y > 40);
    if (floatCall) floatCall.classList.toggle('is-on', y > 700);
  }
  window.addEventListener('scroll', onScrollChrome, { passive: true });
  onScrollChrome();

  /* ---------- nav: mega menus (desktop) / accordion drawer (mobile) ---------- */
  var navItems = $$('.nav__item'), hoverTimer;
  function closeMenus(except) {
    navItems.forEach(function (li) {
      if (li === except) return;
      li.classList.remove('is-open');
      $('.nav__btn', li).setAttribute('aria-expanded', 'false');
    });
  }
  function openMenu(li) {
    closeMenus(li);
    li.classList.add('is-open');
    $('.nav__btn', li).setAttribute('aria-expanded', 'true');
  }
  navItems.forEach(function (li) {
    var btn = $('.nav__btn', li);
    btn.addEventListener('click', function () {
      if (li.classList.contains('is-open')) { closeMenus(); } else { openMenu(li); }
    });
    li.addEventListener('mouseenter', function () {
      if (!desktopNav.matches) return;
      clearTimeout(hoverTimer);
      hoverTimer = setTimeout(function () { openMenu(li); }, 90);
    });
    li.addEventListener('mouseleave', function () {
      if (!desktopNav.matches) return;
      clearTimeout(hoverTimer);
      hoverTimer = setTimeout(closeMenus, 160);
    });
  });
  document.addEventListener('click', function (e) {
    if (desktopNav.matches && !e.target.closest('.nav')) closeMenus();
  });

  var burger = $('.hdr__burger'), nav = $('#nav');
  function setDrawer(open) {
    document.body.classList.toggle('nav-open', open);
    burger.setAttribute('aria-expanded', String(open));
    document.body.style.overflow = open ? 'hidden' : '';
    if (open) { $('.nav__close').focus(); } else { closeMenus(); }
  }
  burger.addEventListener('click', function () { setDrawer(true); });
  $('.nav__close').addEventListener('click', function () { setDrawer(false); burger.focus(); });
  $('[data-scrim]').addEventListener('click', function () { setDrawer(false); });
  desktopNav.addEventListener('change', function () { setDrawer(false); });

  /* ---------- search overlay ---------- */
  var search = $('#search');
  function setSearch(open) {
    search.hidden = !open;
    document.body.style.overflow = open ? 'hidden' : '';
    if (open) setTimeout(function () { $('#q').focus(); }, 30);
  }
  $$('[data-open-search]').forEach(function (b) { b.addEventListener('click', function () { setSearch(true); }); });
  $('[data-close-search]').addEventListener('click', function () { setSearch(false); });

  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') return;
    if (!search.hidden) setSearch(false);
    if (document.body.classList.contains('nav-open')) { setDrawer(false); burger.focus(); }
    closeMenus();
    closeVideo();
  });

  /* ---------- hero banner slideshow ---------- */
  var hero = $('.hero'), slides = $$('.hero__slide'), dots = $$('.hero__dots button'), heroIdx = 0, heroTimer;
  if (hero && slides.length) (function () {
  function showSlide(i) {
    slides[heroIdx].classList.remove('is-on');
    dots[heroIdx].setAttribute('aria-selected', 'false');
    heroIdx = (i + slides.length) % slides.length;
    slides[heroIdx].classList.add('is-on');
    dots[heroIdx].setAttribute('aria-selected', 'true');
    // lazy slides load when they are first shown
    var img = $('img', slides[heroIdx]); if (img.loading === 'lazy') img.loading = 'eager';
  }
  function startHero() {
    if (reduceMotion) return;
    clearInterval(heroTimer);
    heroTimer = setInterval(function () { showSlide(heroIdx + 1); }, 6000);
  }
  dots.forEach(function (d, i) { d.setAttribute('aria-label', 'Slide ' + (i + 1)); d.addEventListener('click', function () { showSlide(i); startHero(); }); });
  $$('[data-hero-dir]').forEach(function (b) { b.addEventListener('click', function () { showSlide(heroIdx + Number(b.dataset.heroDir)); startHero(); }); });
  hero.addEventListener('mouseenter', function () { clearInterval(heroTimer); });
  hero.addEventListener('mouseleave', startHero);
  // swipe on touch screens
  var touchX = null;
  hero.addEventListener('touchstart', function (e) { touchX = e.touches[0].clientX; }, { passive: true });
  hero.addEventListener('touchend', function (e) {
    if (touchX === null) return;
    var dx = e.changedTouches[0].clientX - touchX; touchX = null;
    if (Math.abs(dx) > 40) { showSlide(heroIdx + (dx < 0 ? 1 : -1)); startHero(); }
  });
  startHero();
  })();

  /* ---------- sale countdown ---------- */
  var cd = $('[data-countdown]');
  if (cd) {
    var end = new Date(cd.dataset.countdown).getTime();
    var cells = { d: $('[data-cd="d"]', cd), h: $('[data-cd="h"]', cd), m: $('[data-cd="m"]', cd), s: $('[data-cd="s"]', cd) };
    var pad = function (n) { return (n < 10 ? '0' : '') + n; };
    var tick = function () {
      var t = Math.max(0, end - Date.now());
      cells.d.textContent = pad(Math.floor(t / 864e5));
      cells.h.textContent = pad(Math.floor(t / 36e5) % 24);
      cells.m.textContent = pad(Math.floor(t / 6e4) % 60);
      cells.s.textContent = pad(Math.floor(t / 1e3) % 60);
    };
    tick(); setInterval(tick, 1000);
  }

  /* ---------- category filters (inside the category slider) ---------- */
  var catTrack = $('[data-cats]'), catRail = $('[data-rail="cats"]');
  $$('.filter').forEach(function (f) {
    f.addEventListener('click', function () {
      $$('.filter').forEach(function (o) { o.classList.toggle('is-on', o === f); o.setAttribute('aria-pressed', String(o === f)); });
      var g = f.dataset.filter, n = 0;
      $$('.cat', catTrack).forEach(function (c) {
        var show = g === 'all' || c.dataset.group === g;
        c.classList.toggle('is-hidden', !show);
        c.classList.remove('is-pop');
        if (show && !reduceMotion) { void c.offsetWidth; c.style.animationDelay = Math.min(n++, 6) * 40 + 'ms'; c.classList.add('is-pop'); }
      });
      catRail.scrollLeft = 0;
      catRail.dispatchEvent(new Event('scroll'));
    });
  });

  /* ---------- rails: arrows + progress ---------- */
  $$('[data-rail]').forEach(function (rail) {
    var key = rail.dataset.rail;
    var ctrl = $('[data-rail-ctrl="' + key + '"]');
    var bar = $('[data-rail-progress="' + key + '"] span');
    var btns = (ctrl ? $$('.rail-btn', ctrl) : []).concat($$('[data-rail-for="' + key + '"]'));
    var update = function () {
      var max = rail.scrollWidth - rail.clientWidth;
      var ratio = rail.clientWidth / rail.scrollWidth;
      if (bar) {
        bar.style.width = (ratio * 100) + '%';
        bar.style.transform = 'translateX(' + (max > 0 ? (rail.scrollLeft / max) * ((1 - ratio) / ratio) * 100 : 0) + '%)';
      }
      btns.forEach(function (b) { b.disabled = b.dataset.dir === '-1' ? rail.scrollLeft <= 2 : rail.scrollLeft >= max - 2; });
    };
    btns.forEach(function (b) {
      b.addEventListener('click', function () {
        var item = $('.rail__track > li', rail);
        var step = item ? item.getBoundingClientRect().width + parseFloat(getComputedStyle($('.rail__track', rail)).columnGap || 0) : rail.clientWidth * .8;
        rail.scrollBy({ left: step * Number(b.dataset.dir), behavior: reduceMotion ? 'auto' : 'smooth' });
      });
    });
    rail.addEventListener('scroll', update, { passive: true });
    window.addEventListener('resize', update);
    update();
  });

  /* ---------- wishlist + quick add (demo state — Shopify cart API replaces this) ---------- */
  var cartCount = $('[data-cart-count]'), cartLink = $('[data-cart-link]'), wishCount = $('[data-wish-count]');
  var cart = 0, wishes = 0;
  // shop.js adds quantities through this hook
  window.fsCart = function (n, label) {
    cart += n;
    cartCount.textContent = cart;
    cartLink.setAttribute('aria-label', 'Cart, ' + cart + ' item' + (cart > 1 ? 's' : ''));
    toast('Added to cart — ' + label + (n > 1 ? ' × ' + n : ''));
  };
  window.fsToast = toast;
  $$('.pcard__wish').forEach(function (b) {
    b.addEventListener('click', function () {
      var on = b.getAttribute('aria-pressed') !== 'true';
      b.setAttribute('aria-pressed', String(on));
      wishes += on ? 1 : -1;
      wishCount.textContent = wishes; wishCount.hidden = wishes === 0;
      toast(on ? 'Saved to your wishlist' : 'Removed from your wishlist');
    });
  });
  $$('[data-add]').forEach(function (b) {
    b.addEventListener('click', function () {
      cart += 1;
      cartCount.textContent = cart;
      cartLink.setAttribute('aria-label', 'Cart, ' + cart + ' item' + (cart > 1 ? 's' : ''));
      b.classList.add('is-added');
      b.firstChild.nodeValue = 'Added ';
      setTimeout(function () { b.classList.remove('is-added'); b.firstChild.nodeValue = 'Add to cart '; }, 1800);
      toast('Added to cart — ' + b.dataset.add);
    });
  });

  var nl = $('[data-newsletter]');
  nl.addEventListener('submit', function (e) {
    e.preventDefault();
    var input = $('input', nl), msg = $('.ftr__msg', nl);
    if (!input.checkValidity()) { msg.textContent = 'Please enter a valid email address.'; input.focus(); return; }
    msg.textContent = 'Thank you — you’re on the list.'; input.value = '';
  });

  /* ---------- video modal (YouTube loads only on click) ---------- */
  var vmodal = $('.vmodal'), vframe = $('.vmodal__frame'), lastVideoBtn;
  function closeVideo() {
    if (!vmodal || vmodal.hidden) return;
    vmodal.hidden = true; vframe.innerHTML = ''; document.body.style.overflow = '';
    if (lastVideoBtn) lastVideoBtn.focus();
  }
  $$('[data-yt]').forEach(function (b) {
    b.addEventListener('click', function () {
      lastVideoBtn = b;
      vframe.innerHTML = '<iframe src="https://www.youtube-nocookie.com/embed/' + b.dataset.yt + '?autoplay=1&rel=0" title="' + b.getAttribute('aria-label').replace('Play video: ', '') + '" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe>';
      vmodal.hidden = false; document.body.style.overflow = 'hidden';
      $('.vmodal__close').focus();
    });
  });
  if (vmodal) {
    $('.vmodal__close').addEventListener('click', closeVideo);
    vmodal.addEventListener('click', function (e) { if (e.target === vmodal) closeVideo(); });
  }

  /* ---------- seamless marquees: clone the track content once ---------- */
  $$('.logos__track, .gallery__track').forEach(function (track) {
    $$(':scope > li', track).forEach(function (li) {
      var c = li.cloneNode(true);
      c.setAttribute('aria-hidden', 'true');
      $$('a', c).forEach(function (a) { a.tabIndex = -1; });
      $$('img', c).forEach(function (img) { img.alt = ''; });
      track.appendChild(c);
    });
  });

  /* ---------- homepage SEO copy: collapse to a preview with Read more ---------- */
  var seoBody = $('[data-seo]'), seoToggle = $('[data-seo-toggle]');
  if (seoBody && seoToggle) {
    seoBody.classList.add('is-collapsed');
    seoToggle.hidden = false;
    seoToggle.addEventListener('click', function () {
      var open = seoToggle.getAttribute('aria-expanded') !== 'true';
      seoBody.classList.toggle('is-collapsed', !open);
      seoToggle.setAttribute('aria-expanded', String(open));
      seoToggle.firstChild.nodeValue = open ? 'Read less ' : 'Read more ';
      // collapsing from far down the text would strand the reader, so bring the block back into view
      if (!open) window.scrollTo({ top: seoBody.getBoundingClientRect().top + window.scrollY - 120, behavior: reduceMotion ? 'auto' : 'smooth' });
    });
  }

  /* ---------- guide index: highlight the chapter in view ---------- */
  var chapters = $$('.chapter'), chapLinks = $$('.story__index a');
  if ('IntersectionObserver' in window && chapters.length) {
    var chapIO = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        chapLinks.forEach(function (a) { a.classList.toggle('is-on', a.getAttribute('href') === '#' + en.target.id); });
      });
    }, { rootMargin: '-35% 0px -55% 0px' });
    chapters.forEach(function (c) { chapIO.observe(c); });
  }

  /* ---------- reveal: observer + scroll sweep fallback so content never stays hidden ---------- */
  var reveals = $$('.reveal');
  function sweep() {
    var vh = window.innerHeight || document.documentElement.clientHeight;
    reveals = reveals.filter(function (el) {
      if (el.getBoundingClientRect().top < vh * .92) { el.classList.add('is-in'); return false; }
      return true;
    });
    if (!reveals.length) window.removeEventListener('scroll', sweep);
  }
  if (reduceMotion) { reveals.forEach(function (el) { el.classList.add('is-in'); }); reveals = []; }
  else {
    if ('IntersectionObserver' in window) {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('is-in'); io.unobserve(en.target); } });
      }, { rootMargin: '0px 0px -8% 0px' });
      reveals.forEach(function (el) { io.observe(el); });
    }
    window.addEventListener('scroll', sweep, { passive: true });
    sweep();
  }

})();
