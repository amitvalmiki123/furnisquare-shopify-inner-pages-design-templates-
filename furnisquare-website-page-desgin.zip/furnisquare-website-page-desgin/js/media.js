/* Furnisquare media page — outlet grid with search + "Show more".
   In the Shopify theme this list comes from the page's media metaobject; here it is static sample data. */
(function () {
  'use strict';
  var F = 'https://furnisquare.com/cdn/shop/files/';
  var DATE = '3 Sep 2025';
  var items = [
    ['ANI', 'aninews.in', 'https://www.aninews.in/news/business/online-furniture-store-furnisquare-announce-new-initiative-free-shipping-across-india-to-customers20250903113148/', 'mediaimg74449049-8c49-458d-9160-f60d4f964e54.png?v=1779105075'],
    ['Tribune India', 'tribuneindia.com', 'https://www.tribuneindia.com/news/business/online-furniture-store-furnisquare-announce-new-initiative-free-shipping-across-india-to-customers/', 'mediaimgd7c2b7ff-3f9e-4923-ee2b-141cb40afdb7.png?v=1779105133'],
    ['Mid-day', 'mid-day.com', 'https://www.mid-day.com/buzzfeed/article/furnisquare-free-shipping-india-online-furniture-store-initiative-7261', 'mediaimgfa7d4726-6583-4d17-8b79-71e287f32bd8.png?v=1779103349'],
    ['Lokmat Times', 'lokmattimes.com', 'https://www.lokmattimes.com/business/online-furniture-store-furnisquare-announce-new-initiative-free-shipping-across-india-to-customers/', 'mediaimg18bdd16d-85f1-4684-ab05-0a8cb53b319b.png?v=1779105272'],
    ['LatestLY', 'latestly.com', 'https://www.latestly.com/agency-news/business-news-online-furniture-store-furnisquare-announce-new-initiative-free-shipping-across-india-to-customers-7091388.html', 'mediaimg89676120-07eb-45ed-80dd-e2d900d4fcef.png?v=1779105170'],
    ['Big News Network', 'bignewsnetwork.com', 'https://www.bignewsnetwork.com/news/278549336/online-furniture-store-furnisquare-announce-new-initiative-free-shipping-across-india-to-customers', 'mediaimgacc716fb-a0db-4085-ee40-c3ef92943511.png?v=1779105312'],
    ['UP18 News', 'up18news.com', 'https://up18news.com/online-furniture-store-furnisquare-announce-new-initiative-free-shipping-across-india-to-customers/', 'mediaimg93ecc566-82e0-41e3-84e0-97e34d47ef87.png?v=1779105227'],
    ['WebIndia123', 'news.webindia123.com', 'https://news.webindia123.com/news/Articles/Business/20250903/4356889.html', 'mediaimgf600fd64-2025-47f6-f882-0f8dbfa7a878.png?v=1779253797'],
    ['News9 Network', 'news9network.com', 'https://news9network.com/online-furniture-store-furnisquare-announce-new-initiative-free-shipping-across-india-to-customers/', 'mediaimgbb0da195-2d04-4149-fa87-ec5d387c799b.png?v=1779254196'],
    ['KBK Times', 'kbktimes.com', 'https://kbktimes.com/online-furniture-store-furnisquare-announce-new-initiative-free-shipping-across-india-to-customers/', 'mediaimg65922247-e2af-415b-8a0e-59319fa73ef5.png?v=1779254259'],
    ['News Nation', 'english.newsnationtv.com', 'https://english.newsnationtv.com/business/online-furniture-store-furnisquare-announce-new-initiative-free-shipping-across-india-to-customers20250903113148', 'mediaimg6a3f34e3-cd76-4658-ba4e-255e04df3f92.jpg?v=1779254294'],
    ['Sangri Times', 'en.sangritimes.com', 'https://en.sangritimes.com/spotlight/online-furniture-store-furnisquare-announce-new-initiative-free-shipping-across-india-to-customers', 'mediaimg0ccd3c15-b1f8-455e-f537-39c7191be44f_51a2bf6c-0334-4d43-8532-bbe8c7e2b5e2.png?v=1780474608'],
    ['Daily Prabhat', 'dailyprabhat.com', 'https://www.dailyprabhat.com/online-furniture-store-furnisquare-announce-new-initiative-free-shipping-across-india-to-customers/', 'mediaimgfc4b9959-d312-4ab0-a93d-ce5fa75d2241_5bb68028-f785-4d59-a6a5-c57c4f8d0d1e.png?v=1780474551'],
    ['Dailyhunt', 'm.dailyhunt.in', 'https://m.dailyhunt.in/news/india/english/ani+english-epaper-anieng/online+furniture+store+furnisquare+announce+new+initiative+free+shipping+across+india+to+customers-newsid-n679459601?sm=', 'mediaimga4eba0b5-cbac-4847-bf9f-8c2cd63d23fe_82fd02a4-f126-4962-a31a-8af9ad4606fa.png?v=1780474495'],
    ['The News Net', 'thenewsnet.in', 'https://thenewsnet.in/furnisquare-redefines-online-furniture-shopping-with-free-nationwide-shipping/', 'cropped-thenewsnet.jpg?v=1780512859'],
    ['The Daily Glimpse', 'thedailyglimpse.in', 'https://thedailyglimpse.in/furnisquare-redefines-online-furniture-shopping-with-free-nationwide-shipping/', '132.png?v=1780512808'],
    ['Reach News', 'reachnews.in', 'https://reachnews.in/furnisquare-redefines-online-furniture-shopping-with-free-nationwide-shipping/', '131.png?v=1780512717'],
    ['Rajasthan Ki Khabar', 'rajasthankikhabar.com', 'https://www.rajasthankikhabar.com/news/online-furniture-store-furnisquare-announce-new-initiative-free-shipping-across-india-to-customers20250903113138', 'mediaimg27feab26-61ec-473f-8fa6-a86ce7867f33.png?v=1779255050'],
    ['Rajasthan Journal', 'rajasthanjournal.com', 'https://rajasthanjournal.com/business/online-furniture-store-furnisquare-announce-new-initiative-free-shipping-across-india-to-customers', 'mediaimg74b9473e-88ca-4f18-b0fb-254660a363d0.png?v=1779293924'],
    ['Pink City Now', 'pinkcitynow.com', 'https://pinkcitynow.com/index.php/business/online-furniture-store-furnisquare-announce-new-initiative-free-shipping-across-india-to-customers', 'mediaimgb4581f80-a25f-4ff1-88d1-f1dafb7c0ea2.png?v=1779373166'],
    ['Udaipur Dispatch', 'udaipurdispatch.com', 'https://udaipurdispatch.com/business/online-furniture-store-furnisquare-announce-new-initiative-free-shipping-across-india-to-customers', 'mediaimg0a47cd80-3449-4ee4-b10d-ae798c20dc94.png?v=1779372919'],
    ['Jodhpur Reporter', 'jodhpurreporter.com', 'https://jodhpurreporter.com/index.php/business/online-furniture-store-furnisquare-announce-new-initiative-free-shipping-across-india-to-customers', 'mediaimg0feb1218-8c66-44d7-a26d-11adf0acb600.png?v=1779372994'],
    ['Delhi Live News', 'delhilivenews.in', 'https://www.delhilivenews.in/news/online-furniture-store-furnisquare-announce-new-initiative-free-shipping-across-india-to-customers20250903113138', 'mediaimg8b8fbd08-bb14-42b8-fcab-f4c5e1bfc384.png?v=1779254846'],
    ['Gujarat Samachar', 'gujaratsamachar.news', 'https://www.gujaratsamachar.news/news/online-furniture-store-furnisquare-announce-new-initiative-free-shipping-across-india-to-customers20250903113138', 'mediaimge6152d58-0d46-4691-f879-167dfbea253d.png?v=1779254934'],
    ['Maharashtra Samachar', 'maharashtrasamachar.com', 'https://www.maharashtrasamachar.com/news/online-furniture-store-furnisquare-announce-new-initiative-free-shipping-across-india-to-customers20250903113138', 'mediaimgd6758260-1e22-4c29-9ce2-da7aff70d669.png?v=1779254538'],
    ['Haryana Today', 'haryanatoday.in', 'https://www.haryanatoday.in/news/online-furniture-store-furnisquare-announce-new-initiative-free-shipping-across-india-to-customers20250903113138', 'mediaimgc8586ecc-f87c-4dbb-d5ca-5d920423a1df.png?v=1779254444'],
    ['Karnataka Live', 'karnatakalive.in', 'https://www.karnatakalive.in/news/online-furniture-store-furnisquare-announce-new-initiative-free-shipping-across-india-to-customers20250903113138', 'mediaimg227580c2-a7f9-487e-fcf8-5525958bd4d4.png?v=1779255003'],
    ['Toronto Sun Times', 'torontosuntimes.com', 'https://www.torontosuntimes.com/news/online-furniture-store-furnisquare-announce-new-initiative-free-shipping-across-india-to-customers20250903113138', 'mediaimg5a4d3dcb-de01-4d39-f3e1-d07317f88d17.png?v=1779256114'],
    ['London Channel News', 'londonchannelnews.com', 'https://www.londonchannelnews.com/news/online-furniture-store-furnisquare-announce-new-initiative-free-shipping-across-india-to-customers20250903113138', 'mediaimg11667183-d709-4168-83e4-9699daaab47a.png?v=1779293745'],
    ['Dubai City Reporter', 'dubaicityreporter.com', 'https://www.dubaicityreporter.com/news/online-furniture-store-furnisquare-announce-new-initiative-free-shipping-across-india-to-customers20250903113138', 'mediaimg4c66d040-d99c-44cd-ec62-426c5da4ee5f.png?v=1779273097'],
    ['Miami News Herald', 'miaminewsherald.com', 'https://www.miaminewsherald.com/news/online-furniture-store-furnisquare-announce-new-initiative-free-shipping-across-india-to-customers20250903113138', 'mediaimgdfebe328-1e9d-4418-83a6-b814a956534c.png?v=1779267784']
  ];

  var grid = document.querySelector('[data-mm-grid]'), q = document.getElementById('mm-q'),
      count = document.querySelector('[data-mm-count]'), empty = document.querySelector('[data-mm-empty]'),
      more = document.querySelector('[data-mm-more]');
  if (!grid) return;
  var PAGE = 12, shown = PAGE;

  function card(it) {
    var li = document.createElement('li'), a = document.createElement('a');
    a.className = 'mm__card'; a.href = it[2]; a.target = '_blank'; a.rel = 'noopener';
    a.innerHTML = '<span class="mm__thumb"><img loading="lazy" width="300" height="200" alt="" src="' + F + it[3] + '&width=300"></span>' +
      '<span class="mm__body"><strong></strong><span></span><em>Read article</em></span>';
    a.querySelector('strong').textContent = it[0];
    a.querySelector('.mm__body > span').textContent = it[1] + ' · ' + DATE;
    a.setAttribute('aria-label', it[0] + ', opens the article in a new tab');
    a.querySelector('img').addEventListener('error', function () { this.remove(); });
    li.appendChild(a); return li;
  }
  function render() {
    var term = q.value.trim().toLowerCase();
    var list = items.filter(function (it) { return !term || (it[0] + ' ' + it[1]).toLowerCase().indexOf(term) > -1; });
    var vis = term ? list : list.slice(0, shown);
    grid.innerHTML = '';
    vis.forEach(function (it) { grid.appendChild(card(it)); });
    empty.hidden = list.length > 0;
    more.parentElement.hidden = !!term || shown >= list.length;
    count.textContent = term ? list.length + ' of ' + items.length + ' publications' : 'Showing ' + vis.length + ' of ' + items.length + ' publications';
  }
  q.addEventListener('input', function () { render(); });
  more.addEventListener('click', function () { shown += PAGE; render(); });
  render();
})();
