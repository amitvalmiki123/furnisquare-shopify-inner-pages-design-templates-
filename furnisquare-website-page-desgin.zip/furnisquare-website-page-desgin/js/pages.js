/* Furnisquare content pages — form validation + thank-you state (Contact, Bulk Order, Cancel Order).
   The forms use Shopify's contact-form markup (form_type=contact, contact[...] fields), so in the
   theme they post to the store's contact inbox. In this static mockup nothing is sent. */
(function () {
  'use strict';
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };

  function message(input) {
    if (input.validity.valueMissing) return input.type === 'checkbox' ? 'Please tick this to continue.' : 'Please fill this in.';
    if (input.type === 'email') return 'Enter a valid email address.';
    if (input.type === 'tel') return 'Enter a 10-digit mobile number.';
    return 'Please check this field.';
  }

  // FAQ page: build the "All questions" index from the accordion and open the one you jump to
  var nav = document.querySelector('[data-faqnav]');
  if (nav) {
    $$('.faq__list .qa').forEach(function (qa) {
      var li = document.createElement('li'), a = document.createElement('a');
      a.href = '#' + qa.id; a.textContent = qa.querySelector('summary').textContent;
      a.addEventListener('click', function () { qa.open = true; });
      li.appendChild(a); nav.appendChild(li);
    });
    if (location.hash) { var target = document.querySelector(location.hash + '.qa'); if (target) target.open = true; }
  }

  $$('form[data-pform]').forEach(function (form) {
    // phone fields take digits only
    $$('input[type="tel"]', form).forEach(function (i) {
      i.addEventListener('input', function () { i.value = i.value.replace(/\D/g, '').slice(0, 10); });
    });

    form.addEventListener('input', function (e) {
      var wrap = e.target.closest('.ff, .fcheck');
      if (wrap && wrap.classList.contains('is-bad') && e.target.checkValidity()) {
        wrap.classList.remove('is-bad'); e.target.removeAttribute('aria-invalid');
        var err = wrap.querySelector('.ff__err'); if (err) err.remove();
      }
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var first = null;
      $$('input, select, textarea', form).forEach(function (input) {
        if (input.type === 'hidden') return;
        var wrap = input.closest('.ff, .fcheck'); if (!wrap) return;
        var ok = input.checkValidity();
        wrap.classList.toggle('is-bad', !ok);
        if (ok) { input.removeAttribute('aria-invalid'); var old = wrap.querySelector('.ff__err'); if (old) old.remove(); return; }
        input.setAttribute('aria-invalid', 'true');
        if (wrap.classList.contains('ff')) {
          var err = wrap.querySelector('.ff__err');
          if (!err) { err = document.createElement('p'); err.className = 'ff__err'; err.id = input.id + '-err'; wrap.appendChild(err); input.setAttribute('aria-describedby', err.id); }
          err.textContent = message(input);
        }
        if (!first) first = input;
      });
      if (first) { first.focus(); return; }
      var done = form.parentElement.querySelector('[data-pform-done]');
      form.hidden = true;
      if (done) { done.hidden = false; done.focus(); }
    });
  });
})();
