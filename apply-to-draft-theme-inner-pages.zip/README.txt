FURNISQUARE — INNER PAGES (bulk-order-customization) — APPLY TO DRAFT THEME
Scope: draft theme 130907209857 ("Furnisquare Theme", Draft). DO NOT apply to the live theme.

WHAT'S INSIDE (paths mirror the theme root)
  assets/acustom.css                      -> REPLACE existing (it is currently empty)
  snippets/inner-crumbs.liquid            -> NEW FILE
  sections/inner-hero.liquid              -> NEW FILE
  sections/inner-pills.liquid             -> NEW FILE
  sections/inner-enquiry-form.liquid      -> NEW FILE
  sections/inner-split.liquid             -> NEW FILE
  sections/inner-collections.liquid       -> NEW FILE
  templates/page.bulk-order-customization.json -> REPLACE existing (auto-generated main-page version)
(custom.css and every existing file are intentionally NOT included — they must not be touched.)

STEPS (Shopify admin with the DRAFT theme open, e.g. .../themes/130907209857/editor or its code editor)
  1. Online Store > Themes > Furnisquare Theme (Draft) > ⋯ > Edit code
  2. Assets: open "acustom.css" -> delete everything -> paste the repo file content -> Save
  3. Snippets: "Add a new snippet" named "inner-crumbs" -> paste file content -> Save
  4. Sections: "Add a new section" for each of the 5 inner-*.liquid files -> paste -> Save
  5. Templates: open "page.bulk-order-customization.json" -> select all -> paste -> Save
     (ignore "JSON with comments" style — this file is plain JSON)
  6. Customize (eye icon) > Pages > Bulk Order & Customization:
     - Breadcrumb renders above the hero via the hero section (dynamic: Home / Bulk Order & Customization)
     - Page should match the reference design: breadcrumb -> hero -> Who we work with ->
       Why/Form -> Customization split -> Popular for bulk orders
  7. Test: submit the form with a test name/number -> check the store's contact notification
     email inbox for "Bulk order enquiry" (all required checks: 10-digit WhatsApp number)

VERIFY
  - Icons inside "Why choose Furnisquare?" (shield / truck / star / tag) render — they must exist
    in snippets/icon.liquid + assets icon sprite of the theme. If any is blank, flag it.
  - Hero + 5 collection tiles images resolve (they use the same shop_images the homepage uses).
  - Breadcrumb shows "Bulk Order & Customization" (from the Pages admin title), not static text.

ROLLBACK
  - assets/acustom.css: empty it again (that was its original state)
  - delete the 6 new files (5 sections + inner-crumbs snippet)
  - templates/page.bulk-order-customization.json: restore the original content
    { "sections": { "main": { "type": "main-page", "settings": {} } }, "order": ["main"] }

NOTES
  - The reference HTML design lives in furnisquare-website-page-desgin/bulk-order-customization.html.
  - Inner-page CSS lives ONLY in acustom.css so custom.css (client is working in it) is untouched.
  - Forms post as form_type=contact -> store contact inbox. The mockup's demo JS is not used.
  - All copy/images/blocks are editable in the customizer (defaults = reference copy).
  - Breadcrumb is fully dynamic (routes.root_url + page.title); it has no settings by design.
