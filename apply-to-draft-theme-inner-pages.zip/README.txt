FURNISQUARE — INNER PAGES (Bulk Order + About Us) — APPLY TO DRAFT THEME
Scope: draft theme 130907209857 ("Furnisquare Theme", Draft). DO NOT apply to the live theme.
(custom.css and every pre-existing theme file are intentionally NOT included — do not touch them.)

NEW IN v1.7 (stray <p> tags in stored heading values)
  v1.4's richtext fields stored values wrapped in "<p>…</p>". If your store still holds such values
  ANYWHERE (e.g. you uploaded the templates during v1.4/v1.5), the storefront renderer now strips
  the stray <p> tags — the page renders clean regardless.
  ALSO: each field's info text now says exactly what to type and that the section tag is added
  automatically — e.g. type only:  From 35 designs to <em>Furnisquare</em>
  TO CLEAN THE FIELDS YOURSELF (fixes what you see in the editor):
    Option A: for each Heading/Quote field, delete the leading "<p>" and trailing "</p>" if present
              (11 fields across the 2 pages). No template re-upload needed.
    Option B: re-upload both template JSONs — resets those pages' saved settings to the reference
              defaults. Only use this if you made no manual customizer edits yet.
  RE-UPLOAD: sections/*.liquid (render strips + info text). Templates unchanged since v1.5.

NEW IN v1.6 (heading levels visible in the customizer)
  Labels show the storefront tag: "Heading (H1)" (hero only), "Heading (H2)" (sections),
  "Form heading (H2)", "Title (H3)" (cards), "Quote (blockquote)".

NEW IN v1.5 (heading editing)
  Heading fields (and the About Us quote) are "html"-type settings: a raw HTML box.
  Tags are VISIBLE and are saved exactly as typed — e.g.:  Start creating your <em>home</em>
  Text inside <em>...</em> renders in saffron on the storefront. No italic in the editor.
  If the editor ever rejects the "html" type (standard Shopify type, unlikely), ask the developer —
  the fallback is richtext (Italic = saffron).

EARLIER FIXES
  v1.3: sections/inner-trust.liquid — removed blank "default": "" on Badge text (FileSaveError).
  v1.2: Inner Collections tiles use a COLLECTION PICKER; Name/Image/Alt fall back to the collection.
  v1.1: heading info cleanup.

WHAT'S INSIDE (paths mirror the theme root)
  assets/acustom.css                      -> REPLACE (inner pages stylesheet; currently empty in the theme)
  snippets/inner-crumbs.liquid            -> NEW FILE (dynamic Home > page breadcrumb)
  sections/inner-hero.liquid              -> NEW FILE (page header; reused by bulk-order + about-us)
  sections/inner-pills.liquid             -> NEW FILE
  sections/inner-enquiry-form.liquid      -> NEW FILE (real Shopify contact form)
  sections/inner-split.liquid             -> NEW FILE
  sections/inner-collections.liquid       -> NEW FILE (collection picker on tiles)
  sections/inner-milestones.liquid        -> NEW FILE (1989 / 2020 / Today)
  sections/inner-quote.liquid             -> NEW FILE (pull quote band)
  sections/inner-values.liquid            -> NEW FILE (5-card grid; bottom 2 cards render half-width each to fill the row)
  sections/inner-trust.liquid             -> NEW FILE (trust strip; reuses .trust styles from custom.css)
  sections/inner-cta.liquid               -> NEW FILE (espresso CTA band)
  templates/page.bulk-order-customization.json -> bulk page assignment
  templates/page.about-us.json            -> about-us assignment

STEPS (Shopify admin with the DRAFT theme open)
  1. Online Store > Themes > Furnisquare Theme (Draft) > ... > Edit code.
  2. Upload every file listed above to the matching path (Create asset for new files, paste/overwrite).
  3. Upload the TWO images to Shopify Files if they are not already there, keeping these exact names:
       banner-console.webp   (About hero)     — found in the repo under furnisquare-website-page-desgin/images/hero/
       banner-dining.webp    (About story)    — same folder
     (Settings -> Files. The JSON references them as shopify://shop_images/<name>.)
  4. Create the About template with the SAME name the LIVE theme uses for the About inner page.
  5. The page is pre-filled with the reference design's copy. Open the page in the customizer to review.

ICONS: values/trust icons render through the theme's snippets/icon.liquid (name-based).
  The design uses: star, shield, arrow, check, leaf, truck, card, tag, 1989-as-text.
  If any of these names does not exist in your icon.liquid, that icon simply will not render —
  either add the missing icon there or pick a supported name in the block settings.

NOTES
  - custom.css is untouched on purpose. All inner-page CSS lives in acustom.css and is appended AFTER custom.css.
  - Values grid: 3 cards per row on desktop; with 5 cards the bottom row renders 50% + 50% filling the row.
  - Breadcrumb is fully dynamic (Home > {{ page.title }}) — nothing to configure per page.
  - Rollback: delete the uploaded files, or restore the theme from its backup.
