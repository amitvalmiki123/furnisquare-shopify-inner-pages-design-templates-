/* Furnisquare collection + product pages — vanilla JS, loads after script.js. */
(function () {
  'use strict';

  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var toast = window.fsToast || function () {};
  var inr = function (n) { return '₹' + Math.round(n).toLocaleString('en-IN'); };

  /* ======================================================================
     Collection: filters, price range, sort, load more, view
     ====================================================================== */
  var plist = $('[data-plist]');
  if (plist) (function () {
    var PAGE = 16;
    var cards = $$('.pcard--shop', plist);
    var promo = $('[data-promo]', plist);
    var boxes = $$('[data-facet]');
    var pmin = $('[data-pmin]'), pmax = $('[data-pmax]');
    var sortSel = $('[data-sort]');
    var shownMax = PAGE;

    var labels = {};
    boxes.forEach(function (b) { labels[b.dataset.facet + ':' + b.value] = $('span', b.parentNode).textContent; });

    // facet counts (whole collection)
    boxes.forEach(function (b) {
      var n = cards.filter(function (c) { return c.dataset[b.dataset.facet] === b.value; }).length;
      $('[data-n]', b.parentNode).textContent = n;
      b.parentNode.classList.toggle('is-zero', n === 0);
    });

    // price range bounds + histogram
    var prices = cards.map(function (c) { return +c.dataset.price; });
    var lo = Math.floor(Math.min.apply(null, prices) / 1000) * 1000;
    var hi = Math.ceil(Math.max.apply(null, prices) / 1000) * 1000;
    [pmin, pmax].forEach(function (r) { r.min = lo; r.max = hi; });
    pmin.value = lo; pmax.value = hi;
    var BINS = 14, binW = (hi - lo) / BINS, bins = [];
    for (var i = 0; i < BINS; i++) bins.push(0);
    prices.forEach(function (p) { bins[Math.min(BINS - 1, Math.floor((p - lo) / binW))]++; });
    var top = Math.max.apply(null, bins), hist = $('[data-hist]');
    hist.innerHTML = bins.map(function (n) { return '<span style="height:' + (n ? 14 + (n / top) * 86 : 3) + '%"></span>'; }).join('');
    var bars = $$('span', hist);
    var fill = document.createElement('span'); fill.className = 'range__fill'; $('.range').appendChild(fill);

    function priceUI() {
      var a = +pmin.value, b = +pmax.value;
      if (a > b - 2000) { if (this === pmin) { a = b - 2000; pmin.value = a; } else { b = a + 2000; pmax.value = b; } }
      $('[data-pmin-out]').textContent = inr(Math.max(a, Math.min.apply(null, prices)));
      $('[data-pmax-out]').textContent = inr(Math.min(b, Math.max.apply(null, prices)));
      fill.style.left = ((a - lo) / (hi - lo)) * 100 + '%';
      fill.style.width = ((b - a) / (hi - lo)) * 100 + '%';
      bars.forEach(function (s, k) { var mid = lo + binW * (k + .5); s.classList.toggle('is-in', mid >= a && mid <= b); });
    }

    function state() {
      var s = { facets: {}, a: +pmin.value, b: +pmax.value };
      boxes.forEach(function (b) { if (b.checked) (s.facets[b.dataset.facet] = s.facets[b.dataset.facet] || []).push(b.value); });
      return s;
    }

    function sortCards() {
      var v = sortSel.value;
      var key = {
        featured: function (c) { return +c.dataset.pos; },
        'price-asc': function (c) { return +c.dataset.price; },
        'price-desc': function (c) { return -c.dataset.price; },
        'off-desc': function (c) { return -c.dataset.off; },
        ready: function (c) { return (c.dataset.delivery === 'ready' ? 0 : 1000) + +c.dataset.pos; }
      }[v];
      cards.sort(function (x, y) { return key(x) - key(y) || x.dataset.pos - y.dataset.pos; });
      cards.forEach(function (c) { plist.appendChild(c); });
    }

    function render(animate) {
      var s = state(), match = [];
      cards.forEach(function (c) {
        var ok = +c.dataset.price >= s.a && +c.dataset.price <= s.b;
        Object.keys(s.facets).forEach(function (f) { if (s.facets[f].indexOf(c.dataset[f]) < 0) ok = false; });
        c.classList.toggle('is-out', !ok);
        if (ok) match.push(c);
      });
      match.forEach(function (c, k) {
        var hidden = k >= shownMax;
        var was = c.classList.contains('is-more');
        c.classList.toggle('is-more', hidden);
        c.classList.remove('is-pop');
        if (!hidden && (animate || was) && !reduceMotion) { void c.offsetWidth; c.style.animationDelay = Math.min(k % PAGE, 8) * 35 + 'ms'; c.classList.add('is-pop'); }
      });
      var visible = match.filter(function (c) { return !c.classList.contains('is-more'); });
      // optional promo tile sits after the sixth visible card (the TV Units page no longer has one)
      if (promo) {
        promo.hidden = !visible.length;
        var anchor = visible[Math.min(5, visible.length - 1)];
        if (anchor) anchor.after(promo);
      }

      $$('[data-count]').forEach(function (el) { el.textContent = match.length; });
      $('[data-empty]').hidden = match.length > 0;
      var more = $('[data-more]');
      more.hidden = match.length <= PAGE;
      $('[data-shown]').textContent = visible.length;
      $('[data-total]').textContent = match.length;
      $('[data-more-bar]').style.width = (match.length ? visible.length / match.length * 100 : 0) + '%';
      $('[data-load-more]').hidden = visible.length >= match.length;

      // active chips
      var chips = [];
      Object.keys(s.facets).forEach(function (f) { s.facets[f].forEach(function (v) { chips.push({ k: f + ':' + v, t: labels[f + ':' + v] }); }); });
      if (s.a > lo || s.b < hi) chips.push({ k: 'price', t: inr(Math.max(s.a, Math.min.apply(null, prices))) + ' – ' + inr(Math.min(s.b, Math.max.apply(null, prices))) });
      var ul = $('[data-chips]');
      ul.innerHTML = chips.map(function (c) { return '<li><button type="button" data-chip="' + c.k + '">' + c.t + '<svg class="ico" aria-hidden="true"><use href="#i-close"/></svg><span class="sr-only"> — remove filter</span></button></li>'; }).join('') +
        (chips.length > 1 ? '<li><button type="button" class="chip-clear" data-clear>Clear all</button></li>' : '');
      var n = $('[data-active-n]'); n.textContent = chips.length; n.hidden = !chips.length;
    }

    function clearAll() {
      boxes.forEach(function (b) { b.checked = false; });
      pmin.value = lo; pmax.value = hi; priceUI();
      shownMax = PAGE; render(true);
    }

    boxes.forEach(function (b) { b.addEventListener('change', function () { shownMax = PAGE; render(true); }); });
    [pmin, pmax].forEach(function (r) {
      r.addEventListener('input', function () { priceUI.call(r); shownMax = PAGE; render(false); });
      r.addEventListener('change', function () { render(true); });
    });
    sortSel.addEventListener('change', function () { sortCards(); render(true); });
    $('[data-load-more]').addEventListener('click', function () {
      shownMax += PAGE; render(false);
      toast('Showing more TV units');
    });
    document.addEventListener('click', function (e) {
      var chip = e.target.closest('[data-chip]');
      if (chip) {
        var k = chip.dataset.chip;
        if (k === 'price') { pmin.value = lo; pmax.value = hi; priceUI(); }
        else boxes.forEach(function (b) { if (b.dataset.facet + ':' + b.value === k) b.checked = false; });
        shownMax = PAGE; render(true);
      }
      if (e.target.closest('[data-clear]')) clearAll();
    });

    // products per row (desktop)
    $$('[data-cols]').forEach(function (b) {
      b.addEventListener('click', function () {
        $$('[data-cols]').forEach(function (o) { o.setAttribute('aria-pressed', String(o === b)); });
        plist.style.setProperty('--cols', b.dataset.cols);
        try { localStorage.setItem('fs-cols-v2', b.dataset.cols); } catch (err) {}
      });
    });
    try { var saved = localStorage.getItem('fs-cols-v2'); if (saved) { var sb = $('[data-cols="' + saved + '"]'); if (sb) sb.click(); } } catch (err) {}

    // filter drawer (below 1280px)
    var openBtn = $('[data-open-facets]');
    function setFacets(open) {
      document.body.classList.toggle('facets-open', open);
      openBtn.setAttribute('aria-expanded', String(open));
      document.body.style.overflow = open ? 'hidden' : '';
      if (open) setTimeout(function () { $('.facets__head .iconbtn').focus(); }, 50); else openBtn.focus();
    }
    openBtn.addEventListener('click', function () { setFacets(true); });
    $$('[data-close-facets]').forEach(function (b) { b.addEventListener('click', function () { if (document.body.classList.contains('facets-open')) setFacets(false); }); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && document.body.classList.contains('facets-open')) setFacets(false); });

    // desktop: the facets are dropdowns in the toolbar — one open at a time, close on outside click / Escape
    var wideFacets = window.matchMedia('(min-width: 1280px)');
    var facetEls = $$('.facet');
    facetEls.forEach(function (d) {
      d.addEventListener('toggle', function () {
        if (wideFacets.matches && d.open) facetEls.forEach(function (o) { if (o !== d) o.open = false; });
      });
    });
    document.addEventListener('click', function (e) {
      if (wideFacets.matches && !e.target.closest('.facet')) facetEls.forEach(function (d) { d.open = false; });
    });
    document.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape' || !wideFacets.matches) return;
      var open = facetEls.filter(function (d) { return d.open; })[0];
      if (open) { open.open = false; $('summary', open).focus(); }
    });

    priceUI(); render(false);
  })();

  /* ======================================================================
     "Will it fit?" — screen width vs unit width, drawn to scale
     ====================================================================== */
  $$('[data-fit]').forEach(function (stage) {
    var scope = stage.closest('.fit__grid, .fit__panel') || document;
    var sizes = $$('.fit__sizes [data-tv]', scope);
    var unitW = +stage.dataset.unitW, name = stage.dataset.unitName;
    var scene = $('.fit__scene', stage), tv = $('[data-fit-tv]', stage), unit = $('[data-fit-unit]', stage);
    var SPAN = 180, TALL = 158, UNIT_H = 43.18, FLOOR = 6, GAP = 8;   // centimetres; scene is 180 × 158 cm (fits a 75″ screen)
    function show(btn) {
      sizes.forEach(function (b) { b.setAttribute('aria-checked', String(b === btn)); b.tabIndex = b === btn ? 0 : -1; });
      var w = +btn.dataset.w, h = w * 9 / 16, d = btn.dataset.tv;
      unit.style.width = unitW / SPAN * 100 + '%';
      unit.style.left = (SPAN - unitW) / 2 / SPAN * 100 + '%';
      unit.style.height = UNIT_H / TALL * 100 + '%';
      tv.style.width = w / SPAN * 100 + '%';
      tv.style.height = h / TALL * 100 + '%';
      tv.style.left = (SPAN - w) / 2 / SPAN * 100 + '%';
      tv.style.bottom = (FLOOR + (UNIT_H + GAP) / TALL * 100) + '%';
      $('[data-fit-tv-label]', stage).textContent = d + '″ screen · ' + w + ' cm';
      var diff = Math.round(unitW - w), v;
      scene.classList.toggle('is-over', diff < 0);
      if (diff >= 10) v = 'A ' + d + '″ screen is about ' + w + ' cm wide, so ' + name + ' gives <strong>' + diff + ' cm to spare</strong> — about ' + Math.round(diff / 2) + ' cm each side. A balanced fit.';
      else if (diff >= 0) v = '<strong>A close fit.</strong> The picture is about ' + w + ' cm wide — only ' + diff + ' cm narrower than ' + name + '. Check your TV’s full width with its frame.';
      else v = 'A ' + d + '″ screen is about ' + w + ' cm wide — <strong>' + (-diff) + ' cm wider than ' + name + '</strong>. Consider wall-mounting it above, or ask us about a custom size.';
      $('[data-fit-verdict]', stage).innerHTML = v;
    }
    sizes.forEach(function (b, k) {
      b.addEventListener('click', function () { show(b); });
      b.addEventListener('keydown', function (e) {
        var dir = e.key === 'ArrowRight' || e.key === 'ArrowDown' ? 1 : e.key === 'ArrowLeft' || e.key === 'ArrowUp' ? -1 : 0;
        if (!dir) return;
        e.preventDefault();
        var nx = sizes[(k + dir + sizes.length) % sizes.length]; show(nx); nx.focus();
      });
    });
    show(sizes.filter(function (b) { return b.getAttribute('aria-checked') === 'true'; })[0] || sizes[0]);
  });

  /* ======================================================================
     Product: gallery, zoom, lightbox
     ====================================================================== */
  var gal = $('[data-gal]');
  if (gal) (function () {
    var track = $('[data-gal-track]', gal), slides = $$('li', track), thumbs = $$('.gal__thumbs button', gal), idx = 0;
    var fine = window.matchMedia('(hover: hover) and (pointer: fine)');
    function go(i, smooth) {
      idx = (i + slides.length) % slides.length;
      track.scrollTo({ left: idx * track.clientWidth, behavior: smooth === false || reduceMotion ? 'auto' : 'smooth' });
      mark();
    }
    function mark() {
      thumbs.forEach(function (t, k) { if (k === idx) t.setAttribute('aria-current', 'true'); else t.removeAttribute('aria-current'); });
      $('[data-gal-i]', gal).textContent = idx + 1;
      var img = $('img', slides[idx]); if (img.loading === 'lazy') img.loading = 'eager';
    }
    thumbs.forEach(function (t, k) { t.addEventListener('click', function () { go(k); }); t.addEventListener('mouseenter', function () { if (fine.matches) go(k, false); }); });
    $$('[data-gal-dir]', gal).forEach(function (b) { b.addEventListener('click', function () { go(idx + +b.dataset.galDir); }); });
    var st;
    track.addEventListener('scroll', function () {
      clearTimeout(st);
      st = setTimeout(function () { var k = Math.round(track.scrollLeft / track.clientWidth); if (k !== idx) { idx = k; mark(); } }, 80);
    }, { passive: true });
    window.addEventListener('resize', function () { go(idx, false); });

    // hover zoom (mouse only)
    slides.forEach(function (li) {
      var img = $('img', li);
      li.addEventListener('mousemove', function (e) {
        if (!fine.matches) return;
        var r = li.getBoundingClientRect();
        img.style.transformOrigin = ((e.clientX - r.left) / r.width * 100) + '% ' + ((e.clientY - r.top) / r.height * 100) + '%';
        li.classList.add('is-zoom');
      });
      li.addEventListener('mouseleave', function () { li.classList.remove('is-zoom'); });
      li.addEventListener('click', function () { openBox(idx); });
    });

    // lightbox
    var box = $('[data-lbox]'), bimg = $('[data-lbox-img]'), cap = $('[data-lbox-cap]'), bi = 0, lastFocus;
    function paint() {
      var src = $('img', slides[bi]);
      bimg.src = src.currentSrc || src.src; bimg.alt = src.alt;
      cap.textContent = (bi + 1) + ' / ' + slides.length + ' — ' + src.alt;
    }
    function openBox(i) { lastFocus = document.activeElement; bi = i; paint(); box.hidden = false; document.body.style.overflow = 'hidden'; $('[data-lbox-close]').focus(); }
    function closeBox() { if (box.hidden) return; box.hidden = true; document.body.style.overflow = ''; go(bi, false); if (lastFocus) lastFocus.focus(); }
    $('[data-gal-open]').addEventListener('click', function () { openBox(idx); });
    $('[data-lbox-close]').addEventListener('click', closeBox);
    $$('[data-lbox-dir]').forEach(function (b) { b.addEventListener('click', function () { bi = (bi + +b.dataset.lboxDir + slides.length) % slides.length; paint(); }); });
    box.addEventListener('click', function (e) { if (e.target === box || e.target.classList.contains('lbox__fig')) closeBox(); });
    document.addEventListener('keydown', function (e) {
      if (box.hidden) return;
      if (e.key === 'Escape') closeBox();
      if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') { bi = (bi + (e.key === 'ArrowRight' ? 1 : -1) + slides.length) % slides.length; paint(); }
      if (e.key === 'Tab') { // keep focus inside the dialog
        var f = $$('button', box), first = f[0], last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    });
  })();

  /* ======================================================================
     Product: quantity, add to cart, units, delivery estimate, share
     ====================================================================== */
  var qty = $('[data-qty]');
  if (qty) (function () {
    var input = $('input', qty);
    var clamp = function (v) { return Math.max(1, Math.min(10, parseInt(v, 10) || 1)); };
    $$('[data-qty-dir]', qty).forEach(function (b) { b.addEventListener('click', function () { input.value = clamp(+input.value + +b.dataset.qtyDir); }); });
    input.addEventListener('change', function () { input.value = clamp(input.value); });

    $$('[data-buy]').forEach(function (b) {
      b.addEventListener('click', function () {
        var n = clamp(input.value);
        if (window.fsCart) window.fsCart(n, b.dataset.buy);
        b.classList.add('is-added'); b.firstChild.nodeValue = 'Added ';
        setTimeout(function () { b.classList.remove('is-added'); b.firstChild.nodeValue = 'Add to cart '; }, 1800);
      });
    });

    // estimated delivery: 7–10 business days (Mon–Fri) from today
    var addBiz = function (d, n) { d = new Date(d); while (n > 0) { d.setDate(d.getDate() + 1); if (d.getDay() % 6) n--; } return d; };
    var fmt = function (d, withMonth) { return d.toLocaleDateString('en-IN', withMonth ? { day: 'numeric', month: 'short' } : { day: 'numeric' }); };
    var a = addBiz(Date.now(), 7), z = addBiz(Date.now(), 10);
    $('[data-eta]').textContent = 'between ' + (a.getMonth() === z.getMonth() ? fmt(a) : fmt(a, true)) + ' and ' + fmt(z, true) + ' (est.)';

    // inches / centimetres
    var unitBtn = $('[data-units]'), segs = $$('[data-units-seg]');
    function setUnits(cm) {
      $$('[data-dim-in]').forEach(function (el) { el.textContent = cm ? el.dataset.dimCm : el.dataset.dimIn; });
      unitBtn.textContent = cm ? 'Show in inches' : 'Show in cm';
      unitBtn.setAttribute('aria-pressed', String(cm));
      segs.forEach(function (s) { s.setAttribute('aria-pressed', String((s.dataset.unitsSeg === 'cm') === cm)); });
    }
    unitBtn.addEventListener('click', function () { setUnits(unitBtn.getAttribute('aria-pressed') !== 'true'); });
    segs.forEach(function (s) { s.addEventListener('click', function () { setUnits(s.dataset.unitsSeg === 'cm'); }); });

    $('[data-share]').addEventListener('click', function () {
      var url = 'https://furnisquare.com/products/solid-sheesham-wood-tv-entertainment-unit';
      if (navigator.share) { navigator.share({ title: document.title, url: url }).catch(function () {}); return; }
      if (navigator.clipboard) navigator.clipboard.writeText(url).then(function () { toast('Link copied'); }, function () { toast(url); });
      else toast(url);
    });

    // sticky add-to-cart once the main button scrolls away
    var sbar = $('[data-sbar]'), main = $('[data-buy-main]'), sbtn = $('.btn', sbar);
    var sbarOn = null;
    function checkSbar() {
      var on = main.getBoundingClientRect().bottom < 0;
      if (on === sbarOn) return;
      sbarOn = on;
      sbar.classList.toggle('is-on', on);
      sbar.setAttribute('aria-hidden', String(!on));
      sbtn.tabIndex = on ? 0 : -1;
      document.body.classList.toggle('sbar-on', on);
    }
    window.addEventListener('scroll', checkSbar, { passive: true });
    checkSbar();
  })();

  /* ======================================================================
     Product: in-page nav highlight
     ====================================================================== */
  var pnavLinks = $$('[data-pnav] a');
  if (pnavLinks.length && 'IntersectionObserver' in window) {
    var secs = pnavLinks.map(function (a) { return $(a.getAttribute('href')); }).filter(Boolean);
    var pio = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        pnavLinks.forEach(function (a) {
          var on = a.getAttribute('href') === '#' + en.target.id;
          a.classList.toggle('is-on', on);
          if (on && a.parentNode.scrollWidth > a.parentNode.clientWidth) a.parentNode.scrollTo({ left: a.offsetLeft - 24, behavior: 'smooth' });
        });
      });
    }, { rootMargin: '-30% 0px -60% 0px' });
    secs.forEach(function (s) { pio.observe(s); });
  }
})();
